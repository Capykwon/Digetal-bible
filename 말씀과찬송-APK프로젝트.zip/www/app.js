'use strict';
/* ============ 유틸 ============ */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const vib = ms => { try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {} };

/* ============ 데이터 ============ */
const BOOKS = [
['창세기','Genesis','창'],['출애굽기','Exodus','출'],['레위기','Leviticus','레'],['민수기','Numbers','민'],['신명기','Deuteronomy','신'],
['여호수아','Joshua','수'],['사사기','Judges','삿'],['룻기','Ruth','룻'],['사무엘상','1 Samuel','삼상'],['사무엘하','2 Samuel','삼하'],
['열왕기상','1 Kings','왕상'],['열왕기하','2 Kings','왕하'],['역대상','1 Chronicles','대상'],['역대하','2 Chronicles','대하'],['에스라','Ezra','스'],
['느헤미야','Nehemiah','느'],['에스더','Esther','에'],['욥기','Job','욥'],['시편','Psalms','시'],['잠언','Proverbs','잠'],
['전도서','Ecclesiastes','전'],['아가','Song of Songs','아'],['이사야','Isaiah','사'],['예레미야','Jeremiah','렘'],['예레미야애가','Lamentations','애'],
['에스겔','Ezekiel','겔'],['다니엘','Daniel','단'],['호세아','Hosea','호'],['요엘','Joel','욜'],['아모스','Amos','암'],
['오바댜','Obadiah','옵'],['요나','Jonah','욘'],['미가','Micah','미'],['나훔','Nahum','나'],['하박국','Habakkuk','합'],
['스바냐','Zephaniah','습'],['학개','Haggai','학'],['스가랴','Zechariah','슥'],['말라기','Malachi','말'],
['마태복음','Matthew','마'],['마가복음','Mark','막'],['누가복음','Luke','눅'],['요한복음','John','요'],['사도행전','Acts','행'],
['로마서','Romans','롬'],['고린도전서','1 Corinthians','고전'],['고린도후서','2 Corinthians','고후'],['갈라디아서','Galatians','갈'],['에베소서','Ephesians','엡'],
['빌립보서','Philippians','빌'],['골로새서','Colossians','골'],['데살로니가전서','1 Thessalonians','살전'],['데살로니가후서','2 Thessalonians','살후'],['디모데전서','1 Timothy','딤전'],
['디모데후서','2 Timothy','딤후'],['디도서','Titus','딛'],['빌레몬서','Philemon','몬'],['히브리서','Hebrews','히'],['야고보서','James','약'],
['베드로전서','1 Peter','벧전'],['베드로후서','2 Peter','벧후'],['요한일서','1 John','요일'],['요한이서','2 John','요이'],['요한삼서','3 John','요삼'],
['유다서','Jude','유'],['요한계시록','Revelation','계']
];
const CH = [50,40,27,36,34,24,21,4,31,24,22,25,29,36,10,13,10,42,150,31,12,8,66,52,5,48,12,14,3,9,1,4,7,3,3,3,2,14,4,28,16,24,21,28,16,16,13,6,6,4,4,5,3,6,4,3,1,13,5,5,3,5,1,1,1,22];
const TR = {
  krv: { name: '개역한글', full: '성경전서 개역한글판 (1961)', lang: 'ko-KR', tag: '한국어', file: 'data/krv.json' },
  kjv: { name: 'KJV', full: 'King James Version (1769)', lang: 'en-US', tag: 'English', file: 'data/kjv.json' },
  asv: { name: 'ASV', full: 'American Standard Version (1901)', lang: 'en-US', tag: 'English', file: 'data/asv.json' },
  bbe: { name: 'BBE', full: 'Bible in Basic English (1949)', lang: 'en-US', tag: 'English · 쉬운 영어', file: 'data/bbe.json' }
};
const COLORS = 5;

/* ============ 상태 / 저장 ============ */
const LS_KEY = 'bibleapp.v2';
const defaults = { tr: 'krv', tr2: '', b: 0, c: 1, fs: 20, lh: 1.85, font: 'serif', theme: 'paper', rate: 1, voices: {}, pitch: 1, vstyle: '', readNum: false, autoNext: true, wake: false, hl: {}, mine: [], hscale: 100, color: 1, hinst: 'organ', name: null, tour: 0, notif: 0, notifTime: '08:00', pnotif: 0, pTime: '21:00', log: {}, prayers: [], hidden: [], did: '', lastPray: 0 };
let S = { ...defaults };
let memStore = null;
function load() {
  try { const j = JSON.parse(localStorage.getItem(LS_KEY) || 'null'); if (j) S = { ...defaults, ...j }; } catch (e) { if (memStore) S = { ...defaults, ...memStore }; }
}
let saveT = 0;
function save() {
  memStore = S;
  clearTimeout(saveT);
  saveT = setTimeout(() => { try { localStorage.setItem(LS_KEY, JSON.stringify(S)); } catch (e) {} }, 150);
}
load();

/* ============ 토스트 ============ */
let toastT = 0;
function toast(msg, undo) {
  const t = $('#toast');
  t.innerHTML = `<span>${esc(msg)}</span>` + (undo ? '<button id="tUndo">실행 취소</button>' : '');
  t.classList.add('on');
  if (undo) $('#tUndo').onclick = () => { undo(); t.classList.remove('on'); };
  clearTimeout(toastT);
  toastT = setTimeout(() => t.classList.remove('on'), undo ? 4500 : 2200);
}

/* ============ 테마/글꼴 ============ */
function applyLook() {
  const r = document.documentElement;
  const th = S.theme === 'auto' ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'paper') : S.theme;
  r.dataset.theme = th;
  r.style.setProperty('--fs', S.fs + 'px');
  r.style.setProperty('--lh', S.lh);
  r.style.setProperty('--read-font', S.font === 'serif' ? 'var(--serif)' : 'var(--sans)');
  const m = { paper: '#f4eee1', sepia: '#e8d9b8', dark: '#1a1917', black: '#000' }[th];
  const tm = document.querySelector('meta[name=theme-color]'); if (tm) tm.content = m;
}

try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (S.theme === 'auto') applyLook(); }); } catch (e) {}
/* ============ 성경 로딩 ============ */
const cache = {};
async function loadTr(id) {
  if (cache[id]) return cache[id];
  const r = await fetch(TR[id].file);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  cache[id] = await r.json();
  return cache[id];
}

/* 문장 분리: 마침표/물음표/느낌표 기준. 부호가 없으면 절 전체가 한 문장 */
function splitSentences(t) {
  const out = [];
  const re = /[^.!?。？！]+(?:[.!?。？！]+["'”’」』)\]]*)?\s*/g;
  let m;
  while ((m = re.exec(t))) { const s = m[0].trim(); if (s) out.push(s); }
  return out.length ? out : [t];
}
const segKey = (tr, b, c, v, s) => `${tr}|${b}|${c}|${v}|${s}`;
const refName = (b, c, v) => `${BOOKS[b][0]} ${c}${v ? ':' + v : '장'}`;

let curData = null;
async function showChapter(opts = {}) {
  const { verse = 0, keepScroll = false } = opts;
  const reader = $('#reader');
  stopSpeech(true);
  disarm(true);
  $('#refTxt').textContent = `${BOOKS[S.b][0]} ${S.c}장`;
  $('#btnTr').textContent = TR[S.tr].name;
  reader.innerHTML = '<div class="skeleton"><div class="bar"></div><div class="bar"></div><div class="bar"></div><div class="bar"></div><div class="bar"></div></div>';
  let d, d2 = null;
  try {
    d = await loadTr(S.tr);
    if (S.tr2 && S.tr2 !== S.tr) d2 = await loadTr(S.tr2);
  } catch (e) {
    reader.innerHTML = `<div class="empty">본문을 불러오지 못했어요.<br>네트워크를 확인하고 다시 시도해 주세요.<br><br><button class="btn pri" onclick="showChapter()">다시 시도</button></div>`;
    return;
  }
  curData = d;
  const verses = d[S.b] && d[S.b][S.c - 1];
  if (!verses) { S.c = 1; save(); return showChapter(); }
  const v2 = d2 && d2[S.b] && d2[S.b][S.c - 1];
  let h = `<h2>${esc(BOOKS[S.b][1])} · ${esc(TR[S.tr].name)}</h2><div class="chtitle">${esc(BOOKS[S.b][0])} ${S.c}${S.b === 18 ? '편' : '장'}</div><div style="height:14px"></div>`;
  verses.forEach((t, i) => {
    if (!t) return;
    const n = i + 1;
    const segs = splitSentences(t).map((st, si) => {
      const k = segKey(S.tr, S.b, S.c, n, si);
      const hl = S.hl[k];
      return `<span class="s${hl ? ' hl' + hl.c : ''}" data-v="${n}" data-s="${si}" data-key="${esc(k)}">${esc(st)}</span>`;
    }).join(' ');
    const cmp = v2 && v2[i] ? `<div class="v2">${esc(v2[i])}</div>` : '';
    h += `<div class="v${cmp ? ' cmp' : ''}" data-v="${n}"><div class="row"><button class="vn" data-v="${n}" aria-label="${n}절부터 낭독">${n}</button><div class="vt">${segs}${cmp}</div></div></div>`;
  });
  reader.innerHTML = h;
  if (!keepScroll) $('#main').scrollTop = 0;
  if (verse) {
    const el = reader.querySelector(`.v[data-v="${verse}"]`);
    if (el) { setTimeout(() => { el.scrollIntoView({ block: 'center' }); el.classList.add('flash'); setTimeout(() => el.classList.remove('flash'), 1800); }, 60); }
  }
  updateNav();
  save();
  trackChapter();
  if ($('#v-bible').classList.contains('on')) { try { history.replaceState(null, '', '#bible'); } catch (e) {} }
  prefetchNeighbors();
}
function prefetchNeighbors() { /* 같은 번역은 이미 전체가 로드됨 */ }
function updateNav() {
  const first = S.b === 0 && S.c === 1, last = S.b === 65 && S.c === CH[65];
  $('#prevCh').style.visibility = first ? 'hidden' : '';
  $('#nextCh').style.visibility = last ? 'hidden' : '';
}
function go(b, c, v) { S.b = b; S.c = c; S.lastV = v || 0; save(); return showChapter({ verse: v || 0 }); }
function stepChapter(d) {
  let b = S.b, c = S.c + d;
  if (c < 1) { if (b === 0) return false; b--; c = CH[b]; }
  else if (c > CH[b]) { if (b === 65) return false; b++; c = 1; }
  go(b, c); return true;
}
$('#prevCh').onclick = () => stepChapter(-1);
$('#nextCh').onclick = () => stepChapter(1);

/* ============ 시트(바텀시트) ============ */
let openSheet = null;
function showSheet(id) {
  closeSheet(true);
  openSheet = $('#' + id);
  $('#scrim').classList.add('on');
  openSheet.classList.add('on');
}
function closeSheet(quick) {
  if (!openSheet) return;
  openSheet.classList.remove('on'); openSheet = null;
  $('#scrim').classList.remove('on');
}
$('#scrim').onclick = () => closeSheet();
$$('[data-close]').forEach(b => b.onclick = () => closeSheet());

/* 책/장 선택 */
let refMode = 'book', refBook = 0, refTestament = 'nt';
function renderRef() {
  const body = $('#refBody');
  if (refMode === 'book') {
    $('#refTitle').textContent = '책 선택';
    const from = refTestament === 'ot' ? 0 : 39, to = refTestament === 'ot' ? 39 : 66;
    body.innerHTML = `<div class="seg2"><button data-t="ot" class="${refTestament === 'ot' ? 'on' : ''}">구약 39</button><button data-t="nt" class="${refTestament === 'nt' ? 'on' : ''}">신약 27</button></div><div class="grid b">${BOOKS.slice(from, to).map((b, i) => `<button data-b="${from + i}" class="${from + i === S.b ? 'on' : ''}">${b[0]}</button>`).join('')}</div>`;
    $$('[data-t]', body).forEach(x => x.onclick = () => { refTestament = x.dataset.t; renderRef(); });
    $$('[data-b]', body).forEach(x => x.onclick = () => { refBook = +x.dataset.b; if (CH[refBook] === 1) { closeSheet(); go(refBook, 1); } else { refMode = 'ch'; renderRef(); } });
  } else {
    $('#refTitle').textContent = BOOKS[refBook][0];
    body.innerHTML = `<button class="chip" id="refBack" style="margin-bottom:12px">← 책 목록</button><div class="grid c">${Array.from({ length: CH[refBook] }, (_, i) => `<button data-c="${i + 1}" class="${refBook === S.b && i + 1 === S.c ? 'on' : ''}">${i + 1}</button>`).join('')}</div>`;
    $('#refBack').onclick = () => { refMode = 'book'; renderRef(); };
    $$('[data-c]', body).forEach(x => x.onclick = () => { closeSheet(); go(refBook, +x.dataset.c); });
  }
}
$('#btnRef').onclick = () => { refMode = 'book'; refTestament = S.b < 39 ? 'ot' : 'nt'; renderRef(); showSheet('sh-ref'); };

/* 번역 선택 */
function renderTr() {
  const body = $('#trBody');
  body.innerHTML = Object.entries(TR).map(([id, t]) => `<button class="tr-item ${S.tr === id ? 'on' : ''}" data-id="${id}"><div><b>${t.name}</b><span>${t.full}</span></div><span class="tag">${t.tag}</span></button>`).join('') +
    `<div class="row2"><div class="lb">비교 번역 함께 보기<small>본문 아래에 작게 나란히 표시돼요</small></div><select id="cmpSel"><option value="">사용 안 함</option>${Object.entries(TR).map(([id, t]) => `<option value="${id}" ${S.tr2 === id ? 'selected' : ''}>${t.name}</option>`).join('')}</select></div>
     <p class="note">모두 저작권이 만료된 번역본이에요. (개역개정·새번역 등은 대한성서공회 저작권 때문에 담을 수 없어요.)</p>`;
  $$('.tr-item', body).forEach(x => x.onclick = () => { S.tr = x.dataset.id; if (S.tr2 === S.tr) S.tr2 = ''; save(); closeSheet(); showChapter({ keepScroll: true }); });
  $('#cmpSel').onchange = e => { S.tr2 = e.target.value; if (S.tr2 === S.tr) S.tr2 = ''; save(); closeSheet(); showChapter({ keepScroll: true }); };
}
$('#btnTr').onclick = () => { renderTr(); showSheet('sh-tr'); };

/* ============ 낭독(TTS) ============ */
const TTS = { q: [], i: 0, state: 'idle', gen: 0, timer: 0, sleepAt: 0, fast: 0 };
const synth = 'speechSynthesis' in window ? window.speechSynthesis : null;
let voices = [];
function refreshVoices() { if (synth) voices = synth.getVoices() || []; }
if (synth) { refreshVoices(); synth.onvoiceschanged = refreshVoices; }
function langPrefix() { return TR[S.tr].lang.slice(0, 2); }
function voicesFor(prefix) { return voices.filter(v => v.lang && v.lang.toLowerCase().replace('_', '-').startsWith(prefix)); }
function pickVoice() {
  const p = langPrefix();
  const list = voicesFor(p);
  if (!list.length) return null;
  const chosen = list.find(v => v.voiceURI === S.voices[p]);
  if (chosen) return chosen;
  const FEM = /yuna|sora|female|heami|sun-hi|sunhi|seoyeon|jimin|kyoko|samantha|karen|moira|tessa|susan|zira|hazel|fiona|victoria|serena|kate|libby|sonia|\bkod\b|\bkoc\b/i, MAL = /male|injoon|bongjin|gookmin|daniel|alex|fred|george|ryan|guy|david|mark|oliver|thomas|\bkob\b|\bkog\b/i;
  if (S.vstyle) { const re = S.vstyle === 'f' ? FEM : MAL, bad = S.vstyle === 'f' ? MAL : FEM; const g = list.filter(v => re.test(v.name + ' ' + v.voiceURI) && !(bad.test(v.name) && !re.test(v.name))); if (g.length) return g.slice().sort((a, b) => (b.localService ? 0 : 1) - (a.localService ? 0 : 1))[0]; }
  const score = v => (/enhanced|premium|neural|natural|google|yuna|sora/i.test(v.name) ? 2 : 0) + (v.localService ? 0 : 1) + (/compact/i.test(v.name) ? -2 : 0);
  return list.slice().sort((a, b) => score(b) - score(a))[0];
}
function setPlayUI() {
  const playing = TTS.state === 'playing';
  $('#pPlayIco').innerHTML = playing ? '<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>';
  $('#pPlay').setAttribute('aria-label', playing ? '일시정지' : '낭독 시작');
  $('#pSpd').textContent = S.rate.toFixed(1).replace(/\.0$/, '.0') + '×';
  if (TTS.state === 'idle') { $('#pNow').textContent = '낭독 듣기'; $('#pSub').textContent = '▶ 눌러 이 장을 읽어 드려요'; }
}
function markSpeaking(el) {
  $$('#reader .s.speaking').forEach(x => x.classList.remove('speaking'));
  if (!el) return;
  el.classList.add('speaking');
  const r = el.getBoundingClientRect(), m = $('#main').getBoundingClientRect();
  if (r.top < m.top + 60 || r.bottom > m.bottom - 80) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  $('#pNow').textContent = `${BOOKS[S.b][0]} ${S.c}:${el.dataset.v}`;
  $('#pSub').textContent = el.textContent.slice(0, 40);
}
function ttsStart(from) {
  if (!synth) { toast('이 브라우저는 낭독을 지원하지 않아요'); return; }
  TTS.q = $$('#reader .s');
  if (!TTS.q.length) return;
  TTS.i = clamp(from == null ? TTS.i : from, 0, TTS.q.length - 1);
  TTS.gen++; TTS.state = 'playing'; TTS.fast = 0; setPlayUI();
  synth.cancel();
  setTimeout(speakCur, 60);
  requestWake();
  if (!voicesFor(langPrefix()).length && voices.length) toast('이 기기에 ' + (langPrefix() === 'ko' ? '한국어' : '영어') + ' 음성이 없어요. 기기 설정에서 음성을 설치해 주세요');
}
function tryVoice() {
  if (!synth) return; synth.cancel();
  const ko = langPrefix() === 'ko';
  const u = new SpeechSynthesisUtterance(ko ? '태초에 하나님이 천지를 창조하시니라' : 'In the beginning God created the heaven and the earth.');
  u.lang = TR[S.tr].lang; u.rate = S.rate; u.pitch = S.pitch; const v = pickVoice(); if (v) u.voice = v; synth.speak(u);
}
function speakCur() {
  if (TTS.state !== 'playing') return;
  const gen = TTS.gen, el = TTS.q[TTS.i];
  if (!el) return ttsFinish();
  markSpeaking(el);
  let txt = el.textContent;
  if (S.readNum && el.dataset.s === '0') txt = (langPrefix() === 'ko' ? el.dataset.v + '절. ' : 'Verse ' + el.dataset.v + '. ') + txt;
  const u = new SpeechSynthesisUtterance(txt);
  u.lang = TR[S.tr].lang; u.rate = S.rate; u.pitch = S.pitch;
  const v = pickVoice(); if (v) u.voice = v;
  const t0 = Date.now();
  u.onend = () => {
    if (gen !== TTS.gen) return;
    if (Date.now() - t0 < 140 && txt.length > 6) { if (++TTS.fast >= 3) { stopSpeech(); toast('이 기기에서 음성을 재생하지 못했어요. 기기의 음성(TTS) 설정을 확인해 주세요'); return; } } else TTS.fast = 0;
    TTS.i++; if (TTS.i >= TTS.q.length) ttsFinish(); else speakCur(); };
  u.onerror = e => { if (gen !== TTS.gen) return; if (e.error === 'canceled' || e.error === 'interrupted') return; if (++TTS.fast >= 3) { stopSpeech(); toast('이 기기에서 음성을 재생하지 못했어요. 기기의 음성(TTS) 설정을 확인해 주세요'); return; } TTS.i++; if (TTS.i >= TTS.q.length) ttsFinish(); else speakCur(); };
  synth.speak(u);
}
async function ttsFinish() {
  markSpeaking(null);
  if (S.autoNext && TTS.state === 'playing' && !(S.b === 65 && S.c === CH[65])) {
    const keep = TTS.state;
    const ok = stepChapter(1);
    if (ok) { for (let k = 0; k < 60 && !$$('#reader .s').length; k++) await sleep(100); await sleep(250); TTS.state = 'idle'; ttsStart(0); return; }
  }
  stopSpeech(true);
}
function ttsPause() { TTS.gen++; TTS.state = 'paused'; synth && synth.cancel(); setPlayUI(); }
function stopSpeech(silent) {
  TTS.gen++; TTS.state = 'idle';
  try { synth && synth.cancel(); } catch (e) {}
  markSpeaking(null); setPlayUI(); releaseWake();
}
$('#pPlay').onclick = () => { if (TTS.state === 'playing') ttsPause(); else ttsStart(TTS.state === 'paused' ? TTS.i : 0); };
$('#pPrev').onclick = () => { if (TTS.state === 'idle') return toast('먼저 ▶ 를 눌러 주세요'); TTS.i = Math.max(0, TTS.i - 1); ttsStart(TTS.i); };
$('#pNext').onclick = () => { if (TTS.state === 'idle') return toast('먼저 ▶ 를 눌러 주세요'); TTS.i = Math.min(TTS.q.length - 1, TTS.i + 1); ttsStart(TTS.i); };
const RATES = [0.7, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75];
$('#pSpd').onclick = () => { const i = RATES.findIndex(r => Math.abs(r - S.rate) < 0.01); S.rate = RATES[(i + 1) % RATES.length]; save(); setPlayUI(); if (TTS.state === 'playing') ttsStart(TTS.i); };
/* 절 번호를 누르면 그 절부터 낭독 */
let wakeLock = null;
async function requestWake() { if (!S.wake) return; try { wakeLock = await navigator.wakeLock.request('screen'); } catch (e) {} }
function releaseWake() { try { wakeLock && wakeLock.release(); } catch (e) {} wakeLock = null; }
function sleepTimer(min) {
  clearTimeout(TTS.timer); TTS.sleepAt = 0;
  if (!min) return;
  TTS.sleepAt = Date.now() + min * 60000;
  TTS.timer = setTimeout(() => { stopSpeech(); toast('취침 타이머로 낭독을 멈췄어요'); }, min * 60000);
}

/* ============ 형광펜 ============ */
const PEN_SVG = '<svg viewBox="0 0 40 40"><path d="M8 33l3-8 15-15 6 6-15 15z" fill="#fff" stroke="#222" stroke-width="2" stroke-linejoin="round"/><path d="M26 10l6 6 3-3a2.8 2.8 0 0 0 0-4l-2-2a2.8 2.8 0 0 0-4 0z" fill="#222"/><path d="M8 33l3-8 5 5z" fill="currentColor"/></svg>';
const pen = { on: false, seg: null, key: '', rects: [], cover: [], drag: false, color: S.color || 1, el: null, hintEl: null, moved: 0, last: null };
function lineRects(seg) {
  const r = document.createRange(); r.selectNodeContents(seg);
  const base = $('#reader').getBoundingClientRect();
  const rs = [...r.getClientRects()].filter(x => x.width > 3 && x.height > 3).sort((a, b) => a.top - b.top || a.left - b.left);
  const lines = [];
  for (const x of rs) {
    const L = lines.find(l => Math.abs(l.top - x.top) < x.height * 0.5);
    if (L) { L.left = Math.min(L.left, x.left); L.right = Math.max(L.right, x.right); }
    else lines.push({ top: x.top, bottom: x.bottom, left: x.left, right: x.right });
  }
  return lines.map(l => ({ x: l.left - base.left, y: l.top - base.top, w: l.right - l.left, h: l.bottom - l.top }));
}
function arm(seg) {
  disarm(true);
  pen.on = true; pen.seg = seg; pen.key = seg.dataset.key; pen.cover = []; pen.drag = false;
  seg.classList.add('armed');
  const r = seg.getBoundingClientRect(), m = $('#main').getBoundingClientRect();
  if (r.top < m.top + 40 || r.bottom > m.bottom - 140) seg.scrollIntoView({ block: 'center' });
  buildPen();
  const p = $('#penbar'); p.classList.add('on'); syncPenbar();
  vib(12);
}
function buildPen() {
  const reader = $('#reader');
  $('#pen') && $('#pen').remove();
  pen.rects = lineRects(pen.seg);
  const el = document.createElement('div'); el.id = 'pen';
  el.innerHTML = pen.rects.map((r, i) => `<div class="pl" data-i="${i}" style="left:${r.x - 2}px;top:${r.y}px;width:${r.w + 4}px;height:${r.h}px"></div>`).join('') +
    pen.rects.map((r, i) => `<div class="pf" data-i="${i}" style="left:${r.x}px;top:${r.y + r.h * 0.06}px;width:0;height:${r.h * 0.9}px;background:var(--hl${pen.color});opacity:0"></div>`).join('') +
    `<div class="hint" style="left:${pen.rects[0].x}px;top:${pen.rects[0].y}px">쓱 그어 보세요 ✏️</div>`;
  const ico = document.createElement('div'); ico.className = 'pico'; ico.style.color = ['', '#ffd60a', '#6ed682', '#60b0ff', '#ff80aa', '#ffa03c'][pen.color]; ico.innerHTML = PEN_SVG;
  ico.style.left = pen.rects[0].x + 'px'; ico.style.top = (pen.rects[0].y + pen.rects[0].h) + 'px';
  el.appendChild(ico);
  reader.appendChild(el);
  pen.el = el; pen.ico = ico; pen.hint = el.querySelector('.hint');
  /* 처음엔 펜이 문장을 훑는 안내 애니메이션 */
  const r0 = pen.rects[0], total = pen.rects.reduce((a, r) => a + r.w, 0);
  pen.ico.animate([{ transform: 'translate(-4px,-30px)' }, { transform: `translate(${Math.min(r0.w, 180) - 4}px,-30px)` }, { transform: 'translate(-4px,-30px)' }], { duration: 1800, iterations: Infinity, easing: 'ease-in-out' });
}
function syncPenbar() {
  $$('#penbar .dot').forEach(d => d.classList.toggle('sel', +d.dataset.c === pen.color));
  $('#pbErase').style.display = pen.seg && S.hl[pen.key] ? '' : 'none';
  if (pen.ico) pen.ico.style.color = ['', '#ffd60a', '#6ed682', '#60b0ff', '#ff80aa', '#ffa03c'][pen.color];
  $$('#pen .pf').forEach(f => f.style.background = `var(--hl${pen.color})`);
}
function disarm(silent) {
  if (!pen.on && !$('#pen')) { $('#penbar').classList.remove('on'); return; }
  pen.on = false; pen.drag = false;
  $$('#reader .s.armed').forEach(x => x.classList.remove('armed'));
  $('#pen') && $('#pen').remove();
  $('#penbar').classList.remove('on');
  pen.seg = null;
}
function paintFills() {
  $$('#pen .pf').forEach(f => {
    const i = +f.dataset.i, r = pen.rects[i], c = pen.cover[i];
    if (c && c[1] - c[0] > 1) { f.style.opacity = 1; f.style.left = c[0] + 'px'; f.style.width = (c[1] - c[0]) + 'px'; }
    else { f.style.opacity = 0; f.style.width = '0'; }
  });
}
function coverage() {
  const total = pen.rects.reduce((a, r) => a + r.w, 0) || 1;
  const got = pen.cover.reduce((a, c) => a + (c ? c[1] - c[0] : 0), 0);
  return got / total;
}
function penPoint(e) { const b = $('#reader').getBoundingClientRect(); return { x: e.clientX - b.left, y: e.clientY - b.top }; }
function penMove(p) {
  let li = 0, best = 1e9;
  pen.rects.forEach((r, i) => { const d = Math.abs(p.y - (r.y + r.h / 2)); if (d < best) { best = d; li = i; } });
  const r = pen.rects[li];
  const x = clamp(p.x, r.x, r.x + r.w);
  const c = pen.cover[li] || (pen.cover[li] = [x, x]);
  /* 선이 이어지도록: 현재 구간 밖으로 건너뛰면 사이를 메움 */
  c[0] = Math.min(c[0], x); c[1] = Math.max(c[1], x);
  paintFills();
  pen.ico.style.left = p.x + 'px'; pen.ico.style.top = (r.y + r.h) + 'px';
}
document.addEventListener('pointerdown', e => {
  const pl = e.target.closest && e.target.closest('#pen .pl');
  if (!pl || !pen.on) return;
  e.preventDefault();
  pen.drag = true; pen.cover = []; paintFills();
  pen.ico.getAnimations().forEach(a => a.cancel());
  pen.hint && (pen.hint.style.display = 'none');
  try { pl.setPointerCapture(e.pointerId); } catch (_) {}
  penMove(penPoint(e));
}, { passive: false });
document.addEventListener('pointermove', e => {
  if (!pen.drag) return;
  e.preventDefault();
  penMove(penPoint(e));
}, { passive: false });
function penUp() {
  if (!pen.drag) return;
  pen.drag = false;
  if (coverage() >= 0.4) commitHL(pen.color);
  else { toast('조금 더 길게 쭉 그어 주세요'); pen.cover = []; paintFills(); pen.hint && (pen.hint.style.display = ''); }
}
document.addEventListener('pointerup', penUp);
document.addEventListener('pointercancel', penUp);
function commitHL(color) {
  if (!pen.seg) return;
  pen.cover = pen.rects.map(r => [r.x, r.x + r.w]);
  paintFills();
  vib(18);
  const seg = pen.seg, key = pen.key;
  setTimeout(() => { setHL(seg, key, color); disarm(); }, 230);
}
function setHL(seg, key, color) {
  const prev = S.hl[key];
  const [tr, b, c, v] = key.split('|');
  S.hl[key] = { c: color, ts: Date.now(), t: seg.textContent, tr, b: +b, ch: +c, v: +v };
  seg.className = seg.className.replace(/\bhl\d\b/g, '').trim() + ' hl' + color;
  S.color = color; save();
  toast('형광펜을 칠했어요', () => { if (prev) { S.hl[key] = prev; seg.className = seg.className.replace(/\bhl\d\b/g, '').trim() + ' hl' + prev.c; } else { delete S.hl[key]; seg.className = seg.className.replace(/\bhl\d\b/g, '').trim(); } save(); });
}
function eraseHL() {
  if (!pen.seg) return;
  const seg = pen.seg, key = pen.key, prev = S.hl[key];
  delete S.hl[key]; seg.className = seg.className.replace(/\bhl\d\b/g, '').trim(); save();
  disarm();
  toast('형광펜을 지웠어요', () => { S.hl[key] = prev; seg.className += ' hl' + prev.c; save(); });
}
$$('#penbar .dot').forEach(d => d.onclick = () => { pen.color = +d.dataset.c; S.color = pen.color; save(); syncPenbar(); });
$('#pbGo').onclick = () => { if (pen.on) commitHL(pen.color); };
$('#pbErase').onclick = eraseHL;
$('#pbClose').onclick = () => disarm();

/* 줄 사이 빈틈을 눌러도 가장 가까운 문장을 찾아 줌 */
function segAtPoint(e) {
  if (!e.target.closest || !e.target.closest('.vt')) return null;
  let node = null;
  try {
    if (document.caretPositionFromPoint) { const p = document.caretPositionFromPoint(e.clientX, e.clientY); node = p && p.offsetNode; }
    else if (document.caretRangeFromPoint) { const r = document.caretRangeFromPoint(e.clientX, e.clientY); node = r && r.startContainer; }
  } catch (_) {}
  const el = node && (node.nodeType === 3 ? node.parentElement : node);
  const seg = el && el.closest && el.closest('.s');
  if (seg) return seg;
  /* 마지막 수단: 같은 절 안에서 가장 가까운 문장 */
  const seg2 = [...e.target.closest('.vt').querySelectorAll('.s')];
  let best = null, bd = 1e9;
  seg2.forEach(sg => [...sg.getClientRects()].forEach(r => { const dx = e.clientX < r.left ? r.left - e.clientX : e.clientX > r.right ? e.clientX - r.right : 0, dy = e.clientY < r.top ? r.top - e.clientY : e.clientY > r.bottom ? e.clientY - r.bottom : 0; const d = Math.hypot(dx, dy); if (d < bd) { bd = d; best = sg; } }));
  return bd < 28 ? best : null;
}
/* 더블탭 감지 + 절 번호 탭 + 좌우 스와이프 */
const tap = { key: '', t: 0, x: 0, y: 0, down: null };
const reader = $('#reader');
reader.addEventListener('pointerdown', e => { tap.down = { x: e.clientX, y: e.clientY, t: Date.now(), id: e.pointerId, target: e.target }; });
reader.addEventListener('pointerup', e => {
  const d = tap.down; tap.down = null;
  if (!d || pen.drag) return;
  const dx = e.clientX - d.x, dy = e.clientY - d.y;
  if (Math.abs(dx) < 12 && Math.abs(dy) < 12 && Date.now() - d.t < 450) {
    const vn = e.target.closest('.vn');
    if (vn) { const idx = $$('#reader .s').findIndex(s => s.dataset.v === vn.dataset.v); if (idx >= 0) ttsStart(idx); return; }
    const seg = e.target.closest('.s') || segAtPoint(e);
    if (!seg) { if (pen.on) disarm(); tap.key = ''; return; }
    const now = Date.now();
    if (tap.key === seg.dataset.key && now - tap.t < 380 && Math.hypot(e.clientX - tap.x, e.clientY - tap.y) < 30) {
      tap.key = ''; arm(seg);
    } else {
      if (pen.on && pen.seg !== seg) disarm();
      tap.key = seg.dataset.key; tap.t = now; tap.x = e.clientX; tap.y = e.clientY;
    }
  } else if (Math.abs(dx) > 90 && Math.abs(dy) < 45 && !pen.on && Date.now() - d.t < 600 && !d.target.closest('#pen')) {
    stepChapter(dx < 0 ? 1 : -1);
  }
});

/* ============ 검색 ============ */
const KO_NAMES = [];
BOOKS.forEach((b, i) => { KO_NAMES.push([b[0], i]); KO_NAMES.push([b[2], i]); });
KO_NAMES.sort((a, b) => b[0].length - a[0].length);
function parseRef(q) {
  q = q.trim();
  const m = q.match(/^([가-힣]+)\s*(\d+)\s*(?:장|편|:|\s)?\s*(?:(\d+)\s*절?)?$/);
  if (!m) return null;
  const name = m[1];
  const hit = KO_NAMES.find(n => n[0] === name) || KO_NAMES.find(n => n[0].startsWith(name) && name.length >= 2);
  if (!hit) return null;
  const c = +m[2];
  if (c < 1 || c > CH[hit[1]]) return null;
  return { b: hit[1], c, v: m[3] ? +m[3] : 0 };
}
function renderSearch() {
  const body = $('#searchBody');
  body.innerHTML = `<div class="search-box"><input id="q" type="search" placeholder="단어 또는 '요 3:16' 처럼 입력" enterkeyhint="search" autocomplete="off"><button class="btn pri" id="qGo">검색</button></div><div id="qRes"><div class="empty">현재 번역(${esc(TR[S.tr].name)})에서 찾아요.<br>예) <b>사랑</b> · <b>요 3:16</b> · <b>love</b></div></div>`;
  const run = () => doSearch($('#q').value);
  $('#qGo').onclick = run;
  $('#q').onkeydown = e => { if (e.key === 'Enter') run(); };
  setTimeout(() => $('#q').focus(), 300);
}
async function doSearch(q) {
  q = q.trim(); if (!q) return;
  const box = $('#qRes');
  const ref = parseRef(q);
  if (ref) { closeSheet(); return go(ref.b, ref.c, ref.v); }
  box.innerHTML = '<div class="empty">찾는 중…</div>';
  let d; try { d = await loadTr(S.tr); } catch (e) { box.innerHTML = '<div class="empty">불러오지 못했어요.</div>'; return; }
  const ql = q.toLowerCase(), out = []; let total = 0;
  for (let b = 0; b < d.length; b++) for (let c = 0; c < d[b].length; c++) for (let v = 0; v < d[b][c].length; v++) {
    const t = d[b][c][v]; if (t && t.toLowerCase().includes(ql)) { total++; if (out.length < 150) out.push([b, c + 1, v + 1, t]); }
  }
  if (!out.length) { box.innerHTML = `<div class="empty">'${esc(q)}' 검색 결과가 없어요.</div>`; return; }
  const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  box.innerHTML = `<div class="note">${total}개 구절${total > out.length ? ` 중 앞 ${out.length}개` : ''}</div>` + out.map(([b, c, v, t], i) => `<button class="res" data-i="${i}"><b>${BOOKS[b][0]} ${c}:${v}</b>${esc(t).replace(re, m => '<mark>' + m + '</mark>')}</button>`).join('');
  $$('.res', box).forEach(x => x.onclick = () => { const [b, c, v] = out[+x.dataset.i]; closeSheet(); go(b, c, v); });
}
$('#btnSearch').onclick = () => { renderSearch(); showSheet('sh-search'); };

/* ============ 설정 ============ */
function renderSettings() {
  const p = langPrefix();
  const vs = voicesFor(p);
  const body = $('#setBody');
  body.innerHTML = `
  <div class="row2"><div class="lb">내 이름<small>홈 화면 인사와 기도에 쓰여요</small></div><input id="setName" type="text" maxlength="12" value="${esc(S.name || '')}" placeholder="이름 또는 별명" style="width:9em;padding:9px 10px;border:1px solid var(--line);border-radius:10px;background:var(--paper);color:var(--ink);font-size:15px;text-align:right"></div>
  <div class="row2" style="display:block"><div class="lb" style="margin-bottom:8px">화면 색상</div><div class="themes">${[['auto', '자동'], ['paper', '밝게'], ['sepia', '세피아'], ['dark', '어둡게'], ['black', '검정']].map(([t, n]) => `<button data-t="${t}" class="${S.theme === t ? 'on' : ''}">${n}</button>`).join('')}</div></div>
  <div class="row2"><div class="lb">글자 크기<small id="fsV">${S.fs}px</small></div><input type="range" id="fs" min="14" max="34" value="${S.fs}"></div>
  <div class="row2"><div class="lb">줄 간격<small id="lhV">${S.lh.toFixed(2)}</small></div><input type="range" id="lh" min="1.4" max="2.4" step="0.05" value="${S.lh}"></div>
  <div class="row2"><div class="lb">글꼴</div><select id="font"><option value="serif" ${S.font === 'serif' ? 'selected' : ''}>명조 (책 느낌)</option><option value="sans" ${S.font === 'sans' ? 'selected' : ''}>고딕</option></select></div>
  <div class="row2"><div class="lb">낭독 목소리<small>${vs.length ? '이 기기의 음성 ' + vs.length + '개' : '이 번역에 맞는 음성이 없어요'}</small></div><select id="voice"><option value="">자동 (가장 좋은 음성)</option>${vs.map(v => `<option value="${esc(v.voiceURI)}" ${S.voices[p] === v.voiceURI ? 'selected' : ''}>${esc(v.name)}</option>`).join('')}</select></div>
  <div class="row2" style="display:block"><div class="lb" style="margin-bottom:8px">목소리 느낌<small>${vs.length > 1 ? '기기 음성 중 가까운 것을 골라 드려요' : '기기에 음성이 하나뿐이면 높낮이로 바꿔요'}</small></div><div class="themes" id="vst">${[['', '자동'], ['f', '여성 느낌'], ['m', '남성 느낌']].map(([t, n]) => `<button data-v="${t}" class="${(S.vstyle || '') === t ? 'on' : ''}">${n}</button>`).join('')}</div></div>
  <div class="row2"><div class="lb">목소리 높낮이<small id="ptV">${S.pitch.toFixed(2)}</small></div><input type="range" id="pt" min="0.6" max="1.6" step="0.05" value="${S.pitch}"></div>
  <div class="row2"><div class="lb">미리 들어 보기<small>지금 고른 목소리로 한 구절</small></div><button class="mini" id="vTry">▶ 듣기</button></div>
  <div class="row2"><div class="lb">낭독 속도<small id="rtV">${S.rate.toFixed(2)}×</small></div><input type="range" id="rt" min="0.6" max="1.8" step="0.05" value="${S.rate}"></div>
  <div class="row2"><div class="lb">절 번호도 읽기</div><button class="tg ${S.readNum ? 'on' : ''}" id="tgNum" aria-label="절 번호 읽기"></button></div>
  <div class="row2"><div class="lb">다음 장 이어 읽기</div><button class="tg ${S.autoNext ? 'on' : ''}" id="tgNext" aria-label="이어 읽기"></button></div>
  <div class="row2"><div class="lb">낭독 중 화면 켜두기</div><button class="tg ${S.wake ? 'on' : ''}" id="tgWake" aria-label="화면 켜두기"></button></div>
  <div class="row2"><div class="lb">취침 타이머<small>${TTS.sleepAt ? '약 ' + Math.max(1, Math.round((TTS.sleepAt - Date.now()) / 60000)) + '분 뒤 멈춤' : '낭독을 자동으로 멈춰요'}</small></div><select id="sleep"><option value="0">끄기</option><option value="10">10분</option><option value="20">20분</option><option value="30">30분</option><option value="60">60분</option></select></div>
  <div class="row2"><div class="lb">매일 말씀 알림<small>${LN() ? '정해진 시간에 오늘의 성경구절이 알림으로 떠요' : '설치한 앱(APK)에서 쓸 수 있어요'}</small></div><button class="tg ${S.notif ? 'on' : ''}" id="tgNotif" aria-label="매일 말씀 알림"></button></div>
  <div class="row2"><div class="lb">알림 시간</div><input type="time" id="notifTime" value="${S.notifTime}" style="padding:8px 10px;border:1px solid var(--line);border-radius:10px;background:var(--paper);color:var(--ink);font-size:15px"></div>
  <div class="row2"><div class="lb">기도 시간 알림<small>${LN() ? '매일 정한 시간에 기도 시간을 알려 줘요' : '설치한 앱(APK)에서 쓸 수 있어요'}</small></div><button class="tg ${S.pnotif ? 'on' : ''}" id="tgPN" aria-label="기도 시간 알림"></button></div>
  <div class="row2"><div class="lb">기도 시간</div><input type="time" id="pTime" value="${S.pTime}" style="padding:8px 10px;border:1px solid var(--line);border-radius:10px;background:var(--paper);color:var(--ink);font-size:15px"></div>
  <div class="row2"><div class="lb">사용법 다시 보기</div><button class="mini" id="setTour">보기</button></div>
  <p class="note">형광펜은 이 기기의 브라우저에 저장돼요. 문장을 <b>두 번 톡톡</b> 치면 펜이 나타나요.</p>`;
  $('#tgNotif').onclick = async e => {
    if (!LN()) { toast('설치한 앱(APK)에서 쓸 수 있어요'); return; }
    S.notif = S.notif ? 0 : 1; e.currentTarget.classList.toggle('on', !!S.notif); save();
    if (S.notif) { const ok = await scheduleVerseAlerts(); if (!ok) { S.notif = 0; save(); e.currentTarget.classList.remove('on'); toast('알림 권한을 허용해 주세요'); } else toast(`매일 ${S.notifTime}에 말씀을 알려 드릴게요`); }
    else { try { const p = await LN().getPending(); if (p.notifications.length) await LN().cancel({ notifications: p.notifications }); } catch (_) {} toast('알림을 껐어요'); }
  };
  $('#notifTime').onchange = async e => { S.notifTime = e.target.value || '08:00'; save(); if (S.notif && await scheduleVerseAlerts()) toast(`매일 ${S.notifTime}로 바꿨어요`); };
  $('#tgPN').onclick = async e => {
    if (!LN()) { toast('설치한 앱(APK)에서 쓸 수 있어요'); return; }
    S.pnotif = S.pnotif ? 0 : 1; e.currentTarget.classList.toggle('on', !!S.pnotif); save();
    if (S.pnotif) { const ok = await scheduleVerseAlerts(); if (!ok) { S.pnotif = 0; save(); e.currentTarget.classList.remove('on'); toast('알림 권한을 허용해 주세요'); } else toast(`매일 ${S.pTime}에 기도 시간을 알려 드릴게요`); }
    else if (S.notif) { await scheduleVerseAlerts(); toast('기도 알림을 껐어요'); }
    else { try { const p = await LN().getPending(); if (p.notifications.length) await LN().cancel({ notifications: p.notifications }); } catch (_) {} toast('기도 알림을 껐어요'); }
  };
  $('#pTime').onchange = async e => { S.pTime = e.target.value || '21:00'; save(); if (S.pnotif && await scheduleVerseAlerts()) toast(`매일 ${S.pTime}로 바꿨어요`); };
  $('#setTour').onclick = () => { closeSheet(); openTour(); };
  $('#setName').onchange = e => { S.name = cleanName(e.target.value); save(); if ($('#v-home').classList.contains('on')) renderHome(); toast('이름을 저장했어요'); };
  $$('.themes button', body).forEach(b => b.onclick = () => { S.theme = b.dataset.t; save(); applyLook(); renderSettings(); });
  $('#fs').oninput = e => { S.fs = +e.target.value; $('#fsV').textContent = S.fs + 'px'; applyLook(); save(); };
  $('#lh').oninput = e => { S.lh = +e.target.value; $('#lhV').textContent = S.lh.toFixed(2); applyLook(); save(); };
  $('#font').onchange = e => { S.font = e.target.value; applyLook(); save(); };
  $('#voice').onchange = e => { S.voices[p] = e.target.value; save(); };
  $$('#vst button').forEach(b => b.onclick = () => { S.vstyle = b.dataset.v; save(); $$('#vst button').forEach(x => x.classList.toggle('on', x === b)); tryVoice(); });
  $('#pt').oninput = e => { S.pitch = +e.target.value; $('#ptV').textContent = S.pitch.toFixed(2); };
  $('#pt').onchange = () => { save(); tryVoice(); };
  $('#vTry').onclick = tryVoice;
  $('#rt').oninput = e => { S.rate = +e.target.value; $('#rtV').textContent = S.rate.toFixed(2) + '×'; save(); setPlayUI(); };
  $('#tgNum').onclick = e => { S.readNum = !S.readNum; e.currentTarget.classList.toggle('on', S.readNum); save(); };
  $('#tgNext').onclick = e => { S.autoNext = !S.autoNext; e.currentTarget.classList.toggle('on', S.autoNext); save(); };
  $('#tgWake').onclick = e => { S.wake = !S.wake; e.currentTarget.classList.toggle('on', S.wake); save(); };
  $('#sleep').onchange = e => { sleepTimer(+e.target.value); toast(+e.target.value ? e.target.value + '분 뒤 낭독을 멈출게요' : '타이머를 껐어요'); };
}
function openSettings() { refreshVoices(); renderSettings(); showSheet('sh-set'); }
$('#btnSet').onclick = openSettings;

/* ============ 형광펜 모아보기 ============ */
let markFilter = 0;
function renderMarks() {
  const box = $('#marksBox');
  const all = Object.entries(S.hl).map(([k, v]) => ({ k, ...v })).sort((a, b) => b.ts - a.ts);
  const list = markFilter ? all.filter(x => x.c === markFilter) : all;
  const dots = ['', '#ffd60a', '#6ed682', '#60b0ff', '#ff80aa', '#ffa03c'];
  box.innerHTML = `<div class="filters"><button data-f="0" class="${!markFilter ? 'on' : ''}">전체 ${all.length}</button>${[1, 2, 3, 4, 5].map(c => `<button data-f="${c}" class="${markFilter === c ? 'on' : ''}"><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:${dots[c]};margin-right:5px"></span>${all.filter(x => x.c === c).length}</button>`).join('')}</div>` +
    (list.length ? list.map(x => `<div class="mk" data-c="${x.c}" data-k="${esc(x.k)}"><div class="r">${BOOKS[x.b][0]} ${x.ch}:${x.v} · ${TR[x.tr] ? TR[x.tr].name : x.tr}</div><div class="t">${esc(x.t)}</div><div class="a"><button data-a="go">이동</button><button data-a="copy">복사</button><button data-a="del" class="del">삭제</button></div></div>`).join('') + `<div style="display:flex;gap:8px;margin-top:6px"><button class="btn" id="mkCopyAll" style="flex:1">전체 복사</button></div>` :
      `<div class="empty">아직 칠한 문장이 없어요.<br><br>성경 탭에서 문장을 <b>두 번 톡톡</b> 치면<br>형광펜이 나타나고,<br>문장 위를 <b>쓱 그으면</b> 칠해져요 ✏️</div>`);
  $$('.filters button', box).forEach(b => b.onclick = () => { markFilter = +b.dataset.f; renderMarks(); });
  $$('.mk', box).forEach(m => {
    const x = S.hl[m.dataset.k];
    $$('[data-a]', m).forEach(b => b.onclick = async () => {
      if (b.dataset.a === 'go') { S.tr = x.tr; save(); setTab('bible'); go(x.b, x.ch, x.v); }
      else if (b.dataset.a === 'copy') copyText(`${x.t}\n— ${BOOKS[x.b][0]} ${x.ch}:${x.v} (${TR[x.tr].name})`);
      else { const prev = x; delete S.hl[m.dataset.k]; save(); renderMarks(); toast('삭제했어요', () => { S.hl[m.dataset.k] = prev; save(); renderMarks(); }); }
    });
  });
  const ca = $('#mkCopyAll'); if (ca) ca.onclick = () => copyText(list.map(x => `${BOOKS[x.b][0]} ${x.ch}:${x.v} (${TR[x.tr].name})\n${x.t}`).join('\n\n'));
}
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); toast('복사했어요'); }
  catch (e) {
    const ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = 0; document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); toast('복사했어요'); } catch (_) { toast('복사하지 못했어요'); } ta.remove();
  }
}

/* ============ 탭 ============ */
function setTab(t) {
  $$('.tabs button').forEach(b => b.classList.toggle('on', b.dataset.tab === t));
  $$('.view').forEach(v => v.classList.toggle('on', v.id === 'v-' + t));
  $('#player').style.display = t === 'bible' ? '' : 'none';
  $('#topbar').style.display = t === 'bible' ? '' : 'none';
  if (t !== 'bible') { disarm(); if (TTS.state === 'playing') ttsPause(); }
  if (t === 'home') renderHome();
  if (t === 'log') renderLog();
  if (t === 'hymn') renderHymnList();
  if (t === 'marks') renderMarks();
  try { history.replaceState(null, '', '#' + t); } catch (e) {}
  if (t !== 'bible') $('#main').scrollTop = 0;
}
$$('.tabs button').forEach(b => b.onclick = () => setTab(b.dataset.tab));

/* ============ 찬송 ============ */
const HY = { cur: null, v: null, tm: [], notes: [], total: 0, tempo: 76, playing: false, paused: false, ctx: null, master: null, rev: null, t0: 0, p0: 0, rate: 1, semis: 0, raf: 0, idx: -1, loop: false, nodes: [], marked: [], col: null };
function allHymns() { return [...window.HYMNS, ...S.mine.map(m => ({ id: m.id, title: m.title, ko: '내가 추가한 찬송', meta: '', abc: m.abc, mine: true }))]; }
function renderHymnList() {
  const box = $('#hymnList');
  box.innerHTML = `<h2 style="margin:4px 4px 12px;font-size:20px">찬송</h2>` +
    allHymns().map(h => `<button class="hcard" data-id="${esc(h.id)}"><div class="pi"><svg viewBox="0 0 24 24"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg></div><div><b>${esc(h.title)}</b><span>${esc(h.ko || '')}</span>${h.meta ? `<span>${esc(h.meta)}</span>` : ''}</div></button>`).join('') +
    `<button class="btn" id="addHymn" style="width:100%;margin-top:6px">＋ 내 찬송 추가 (악보 + 가사)</button>
     <p class="note">악보는 <b>저작권이 만료된 곡</b>만 담았어요. 재생하면 지금 소리 나는 음표와 그 아래 가사가 <b style="color:var(--red)">빨갛게</b> 바뀌어요.<br>교회에서 쓰는 새찬송가는 한국찬송가공회의 저작권이 있어 직접 넣지 않았어요. 가지고 계신 악보를 ABC 형식으로 추가하면 똑같이 재생·빨간 표시가 돼요.</p>`;
  $$('.hcard', box).forEach(c => c.onclick = () => openHymn(allHymns().find(h => h.id === c.dataset.id)));
  $('#addHymn').onclick = openAdd;
}
function openAdd() {
  const body = $('#addBody');
  body.innerHTML = `<p class="note" style="padding-top:0">ABC 악보 형식으로 붙여넣으세요. <b>w:</b> 로 시작하는 줄이 음표 아래 가사가 돼요. (<code>-</code> 음절 구분, <code>_</code> 앞 음절 늘임, <code>*</code> 건너뜀) 한글 가사도 됩니다.</p><textarea class="abc" id="abcIn" spellcheck="false">${esc(window.ABC_TEMPLATE)}</textarea><div id="abcWarn" class="warn"></div><div style="display:flex;gap:8px;margin-top:8px"><button class="btn" id="abcTest" style="flex:1">미리 확인</button><button class="btn pri" id="abcSave" style="flex:1">저장하고 열기</button></div>`;
  const check = () => {
    const abc = $('#abcIn').value;
    const tmp = document.createElement('div');
    let v; try { v = ABCJS.renderAbc(tmp, abc, {})[0]; } catch (e) { $('#abcWarn').textContent = '악보를 읽을 수 없어요: ' + e.message; return null; }
    const w = (v.warnings || []).map(x => x.replace(/<[^>]+>/g, '')).join('\n');
    if (!v.lines || !v.lines.length) { $('#abcWarn').textContent = '음표를 찾지 못했어요. K: (조표) 줄과 음표 줄이 있는지 확인해 주세요.'; return null; }
    $('#abcWarn').textContent = w ? '확인할 점:\n' + w : '✓ 악보가 잘 읽혀요';
    return { title: (v.metaText && v.metaText.title) || '제목 없음', abc };
  };
  $('#abcTest').onclick = check;
  $('#abcSave').onclick = () => { const r = check(); if (!r) return; const id = 'my-' + Date.now(); S.mine.push({ id, title: r.title, abc: r.abc }); save(); closeSheet(); renderHymnList(); openHymn(allHymns().find(h => h.id === id)); };
  showSheet('sh-add');
}

function ensureAudio() {
  if (!HY.ctx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    HY.ctx = new AC();
    HY.master = HY.ctx.createGain(); HY.master.gain.value = 0.55;
    const comp = HY.ctx.createDynamicsCompressor();
    HY.master.connect(comp); comp.connect(HY.ctx.destination);
    /* 은은한 울림(리버브) */
    const len = HY.ctx.sampleRate * 1.8, ir = HY.ctx.createBuffer(2, len, HY.ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
    const conv = HY.ctx.createConvolver(); conv.buffer = ir;
    const wet = HY.ctx.createGain(); wet.gain.value = 0.28;
    HY.master.connect(conv); conv.connect(wet); wet.connect(comp);
  }
  if (HY.ctx.state === 'suspended') HY.ctx.resume();
}
function tone(midi, when, dur, vel) {
  const ctx = HY.ctx, f = 440 * Math.pow(2, (midi + HY.semis - 69) / 12), inst = S.hinst;
  const g = ctx.createGain(); g.connect(HY.master);
  const vol = (vel / 127) * 0.5;
  let parts, a, rel;
  if (inst === 'piano') { parts = [[1, 'triangle', 1], [2, 'sine', .35], [3, 'sine', .15], [4, 'sine', .06]]; a = 0.006; rel = 0.35; }
  else if (inst === 'flute') { parts = [[1, 'sine', 1], [2, 'sine', .18], [3, 'sine', .05]]; a = 0.06; rel = 0.12; }
  else { parts = [[1, 'sine', 1], [2, 'sine', .55], [3, 'sine', .28], [4, 'sine', .14], [0.5, 'sine', .3]]; a = 0.03; rel = 0.12; }
  const end = when + dur;
  g.gain.setValueAtTime(0.0001, when);
  g.gain.linearRampToValueAtTime(vol, when + a);
  if (inst === 'piano') { g.gain.exponentialRampToValueAtTime(vol * 0.35, when + Math.min(dur, 0.8)); g.gain.exponentialRampToValueAtTime(0.0001, end + rel); }
  else { g.gain.setValueAtTime(vol * 0.85, Math.max(when + a, end - 0.02)); g.gain.linearRampToValueAtTime(0.0001, end + rel); }
  const oscs = parts.map(([m, type, amp]) => {
    const o = ctx.createOscillator(), og = ctx.createGain(); o.type = type; o.frequency.value = f * m; og.gain.value = amp / 2.2;
    if (inst === 'flute') { const lfo = ctx.createOscillator(), lg = ctx.createGain(); lfo.frequency.value = 5; lg.gain.value = f * 0.004; lfo.connect(lg); lg.connect(o.frequency); lfo.start(when); lfo.stop(end + rel + .05); }
    o.connect(og); og.connect(g); o.start(when); o.stop(end + rel + .05); return o;
  });
  HY.nodes.push(...oscs);
  oscs[0].onended = () => { try { g.disconnect(); } catch (e) {} };
}
function hyClearMarks() {
  HY.marked.forEach(e => e.classList.remove('hy-on')); HY.marked = [];
}
function hyMark(i) {
  hyClearMarks();
  if (i < 0) { if (HY.col) HY.col.style.display = 'none'; return; }
  const ev = HY.tm[i], svg = $('#abc svg');
  const addMark = el => {
    el.classList.add('hy-on'); HY.marked.push(el);
    const cls = [...(el.classList || [])];
    const pick = p => cls.find(c => new RegExp('^abcjs-' + p + '\\d+$').test(c));
    const l = pick('l'), m = pick('m'), v = pick('v'), n = pick('n');
    if (l && m && v && n) svg.querySelectorAll(`.abcjs-lyric.${l}.${m}.${v}.${n}`).forEach(x => { x.classList.add('hy-on'); HY.marked.push(x); });
  };
  (ev.elements || []).forEach(g => g.forEach(addMark));
  if (!HY.col || !HY.col.isConnected) { HY.col = document.createElementNS('http://www.w3.org/2000/svg', 'rect'); HY.col.setAttribute('fill', 'rgba(217,45,45,.10)'); HY.col.setAttribute('rx', 4); svg.insertBefore(HY.col, svg.firstChild.nextSibling || svg.firstChild); }
  HY.col.style.display = '';
  HY.col.setAttribute('x', ev.left - 2); HY.col.setAttribute('y', ev.top - 2); HY.col.setAttribute('width', Math.max(ev.width, 12) + 4); HY.col.setAttribute('height', ev.height + 4);
  /* 현재 줄이 보이도록 스크롤 */
  const sc = $('#hsheet'), svgR = svg.getBoundingClientRect(), scR = sc.getBoundingClientRect();
  const k = svgR.width / (svg.viewBox.baseVal && svg.viewBox.baseVal.width ? svg.viewBox.baseVal.width : svgR.width);
  const top = svgR.top + ev.top * k, bot = top + ev.height * k;
  if (top < scR.top + 8 || bot > scR.bottom - 24) sc.scrollTo({ top: sc.scrollTop + (top - scR.top) - 24, behavior: 'smooth' });
}
function openHymn(h) {
  stopHymn();
  HY.cur = h; HY.idx = -1;
  $('#hTitle').firstChild.textContent = h.title;
  $('#hMeta').textContent = h.meta || h.ko || '';
  $('#hDel').style.display = h.mine ? '' : 'none';
  $('#hymn').classList.add('on');
  /* 키 선택 */
  $('#hKey').innerHTML = Array.from({ length: 13 }, (_, i) => i - 6).map(n => `<option value="${n}" ${n === 0 ? 'selected' : ''}>${n === 0 ? '원래 키' : (n > 0 ? '+' + n : n)}</option>`).join('');
  HY.semis = 0; HY.rate = 1; $('#hTempo').value = 100; $('#hTempoV').textContent = '100%'; $('#hScale').value = S.hscale; $('#hInst').value = S.hinst;
  renderSheet();
}
function renderSheet() {
  const h = HY.cur; if (!h) return;
  const wasPlaying = HY.playing;
  const pos = currentPos();
  hyStopAudio();
  const sc = (S.hscale || 100) / 100;
  const avail = Math.min($('#hsheet').clientWidth || window.innerWidth, 900) - 20;
  const w = Math.max(280, avail / sc);
  const perLine = avail < 420 ? 2 : avail < 640 ? 3 : 4;
  $('#abc').innerHTML = '';
  const vs = ABCJS.renderAbc('abc', h.abc, {
    add_classes: true, staffwidth: w, scale: sc, paddingtop: 6, paddingbottom: 10, paddingleft: 0, paddingright: 0,
    visualTranspose: HY.semis, wrap: { minSpacing: 1.5, maxSpacing: 3.2, preferredMeasuresPerLine: perLine },
    clickListener: (el) => { const i = HY.tm.findIndex(t => t.startChar === el.startChar); if (i >= 0) seekTo(HY.tm[i].milliseconds); }
  });
  HY.v = vs[0];
  HY.v.setTiming();
  const seq = HY.v.setUpAudio({});
  HY.tempo = seq.tempo || 80;
  const whole = 4 * 60000 / HY.tempo;
  HY.notes = seq.tracks[0].filter(e => e.cmd === 'note').map(e => ({ p: e.pitch, ms: e.start * whole, d: e.duration * whole, v: e.volume || 90 }));
  HY.tm = HY.v.noteTimings.filter(t => t.type === 'event');
  const last = HY.notes[HY.notes.length - 1];
  HY.total = last ? last.ms + last.d : 0;
  HY.col = null; HY.marked = [];
  HY.idx = -1;
  if (pos > 0 && pos < HY.total) { HY.pos = pos; hyMark(idxAt(pos)); } else HY.pos = 0;
}
function idxAt(ms) { let lo = 0, hi = HY.tm.length - 1, r = -1; while (lo <= hi) { const m = (lo + hi) >> 1; if (HY.tm[m].milliseconds <= ms + 1) { r = m; lo = m + 1; } else hi = m - 1; } return r; }
function currentPos() {
  if (HY.playing && HY.ctx) return HY.p0 + (HY.ctx.currentTime - HY.t0) * 1000 * HY.rate;
  return HY.pos || 0;
}
function hyStopAudio() {
  cancelAnimationFrame(HY.raf);
  HY.nodes.forEach(o => { try { o.stop(); } catch (e) {} });
  HY.nodes = [];
}
function hyStartFrom(ms) {
  ensureAudio();
  hyStopAudio();
  const ctx = HY.ctx; HY.p0 = ms; HY.t0 = ctx.currentTime + 0.08; HY.playing = true; HY.paused = false; if (HY.cur) logAddAuto('hymn', HY.cur.title);
  HY.notes.forEach(n => {
    if (n.ms + n.d <= ms) return;
    const start = Math.max(n.ms, ms);
    const when = HY.t0 + (start - ms) / 1000 / HY.rate, dur = Math.max(0.06, (n.d - (start - n.ms)) / 1000 / HY.rate * 0.98);
    tone(n.p, when, dur, n.v);
  });
  hySetPlayUI();
  const loop = () => {
    if (!HY.playing) return;
    const p = HY.p0 + (ctx.currentTime - HY.t0) * 1000 * HY.rate;
    if (p >= HY.total + 250) { HY.pos = 0; if (HY.loop) { hyStartFrom(0); return; } hyMark(-1); HY.playing = false; hySetPlayUI(); return; }
    const i = idxAt(Math.max(0, p));
    if (i !== HY.idx) { HY.idx = i; hyMark(i); }
    HY.raf = requestAnimationFrame(loop);
  };
  HY.raf = requestAnimationFrame(loop);
}
function seekTo(ms) { HY.pos = ms; if (HY.playing) hyStartFrom(ms); else { hyMark(idxAt(ms)); } }
function hyToggle() {
  if (HY.playing) { HY.pos = currentPos(); HY.playing = false; hyStopAudio(); hySetPlayUI(); return; }
  const start = HY.pos > 0 && HY.pos < HY.total ? HY.pos : 0;
  hyStartFrom(start);
}
function stopHymn() { HY.playing = false; HY.pos = 0; hyStopAudio(); hyClearMarks(); hySetPlayUI(); }
function hySetPlayUI() { const p = $('#hPlayIco'); if (p) p.innerHTML = HY.playing ? '<path d="M7 5h4v14H7zM13 5h4v14h-4z"/>' : '<path d="M8 5v14l11-7z"/>'; $('#hLoop').style.background = HY.loop ? 'var(--accent-soft)' : ''; $('#hLoop').style.color = HY.loop ? 'var(--accent)' : ''; }
$('#hPlay').onclick = hyToggle;
$('#hRestart').onclick = () => { HY.pos = 0; HY.idx = -1; hyClearMarks(); if (HY.col) HY.col.style.display = 'none'; if (HY.playing) hyStartFrom(0); $('#hsheet').scrollTo({ top: 0, behavior: 'smooth' }); };
$('#hLoop').onclick = () => { HY.loop = !HY.loop; hySetPlayUI(); toast(HY.loop ? '반복 재생 켜짐' : '반복 재생 꺼짐'); };
$('#hBack').onclick = () => { stopHymn(); $('#hymn').classList.remove('on'); };
$('#hDel').onclick = () => { if (!HY.cur || !HY.cur.mine) return; const id = HY.cur.id, prev = S.mine.find(m => m.id === id); S.mine = S.mine.filter(m => m.id !== id); save(); $('#hBack').onclick(); renderHymnList(); toast('삭제했어요', () => { S.mine.push(prev); save(); renderHymnList(); }); };
$('#hTempo').oninput = e => { const p = currentPos(); HY.rate = +e.target.value / 100; $('#hTempoV').textContent = e.target.value + '%'; if (HY.playing) { HY.pos = p; hyStartFrom(p); } };
$('#hKey').onchange = e => { HY.semis = +e.target.value; renderSheet(); };
$('#hInst').onchange = e => { S.hinst = e.target.value; save(); if (HY.playing) hyStartFrom(currentPos()); };
let scT = 0;
$('#hScale').oninput = e => { S.hscale = +e.target.value; save(); clearTimeout(scT); scT = setTimeout(renderSheet, 120); };
let rzT = 0;
window.addEventListener('resize', () => { clearTimeout(rzT); rzT = setTimeout(() => { if ($('#hymn').classList.contains('on')) renderSheet(); }, 250); });

/* ============ 키보드 ============ */
document.addEventListener('keydown', e => {
  if (e.target.closest && e.target.closest('input,textarea,select')) return;
  if (e.key === 'Escape') { closeSheet(); disarm(); }
  else if (e.key === ' ' && $('#v-bible').classList.contains('on') && !$('#hymn').classList.contains('on')) { e.preventDefault(); $('#pPlay').click(); }
  else if (e.key === 'ArrowRight' && $('#v-bible').classList.contains('on') && !openSheet) stepChapter(1);
  else if (e.key === 'ArrowLeft' && $('#v-bible').classList.contains('on') && !openSheet) stepChapter(-1);
});
document.addEventListener('visibilitychange', () => { if (document.hidden && HY.playing) { HY.pos = currentPos(); HY.playing = false; hyStopAudio(); hySetPlayUI(); } });



/* ============ 매일 말씀 알림 (APK: Capacitor LocalNotifications) ============ */
const LN = () => (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.LocalNotifications) || null;
async function scheduleVerseAlerts() {
  const ln = LN(); if (!ln || (!S.notif && !S.pnotif)) return false;
  try {
    const p = await ln.requestPermissions(); if (p.display !== 'granted') { S.notif = 0; S.pnotif = 0; save(); return false; }
    const pend = await ln.getPending(); if (pend.notifications && pend.notifications.length) await ln.cancel({ notifications: pend.notifications });
    const list = []; const now = new Date();
    if (S.notif) {
      const d = await loadTr('krv'); const [hh, mm] = (S.notifTime || '08:00').split(':').map(Number);
      for (let i = 0; i < 45; i++) {
        const day = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i, hh, mm, 0);
        if (day <= now) continue;
        const r = vodOn(day), txt = (d[r[0]][r[1] - 1][r[2] - 1] || ''); const body = `${txt}\n— ${BOOKS[r[0]][0]} ${r[1]}:${r[2]}`;
        list.push({ id: 1000 + i, title: '🙏 오늘의 성경구절', body, largeBody: body, schedule: { at: day, allowWhileIdle: true } });
      }
    }
    if (S.pnotif) { const [ph, pm] = (S.pTime || '21:00').split(':').map(Number); list.push({ id: 2000, title: '🙏 기도할 시간이에요', body: '잠시 멈추고 하나님 앞에 기도해요. 오늘의 기도를 남겨 보세요.', schedule: { on: { hour: ph, minute: pm }, allowWhileIdle: true } }); }
    if (list.length) await ln.schedule({ notifications: list }); return true;
  } catch (e) { return false; }
}


/* ============ 출석 체크 / 기록 ============ */
const pad2 = n => String(n).padStart(2, '0');
const dkey = d => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const todayKey = () => dkey(new Date());
const LOGF = [['pray', '기도함', '🙏', 'd-p'], ['worship', '예배함', '⛪', 'd-w'], ['hymn', '찬송함', '🎵', 'd-h'], ['read', '읽음', '📖', 'd-r']];
function dayFlags(e) { return { pray: !!e.pray, worship: !!e.worship, hymn: !!(e.hymns && e.hymns.length), read: !!((e.read && e.read.trim()) || (e.chs && e.chs.length)) }; }
function logEntry(k) { if (!S.log[k]) S.log[k] = {}; return S.log[k]; }
function logTidy(k) { const e = S.log[k]; if (e && !e.pray && !e.worship && !(e.hymns && e.hymns.length) && !(e.read && e.read.trim()) && !(e.chs && e.chs.length)) delete S.log[k]; }
function logAddAuto(kind, val) {
  const k = todayKey(), e = logEntry(k); const arr = kind === 'hymn' ? (e.hymns = e.hymns || []) : (e.chs = e.chs || []);
  if (!arr.includes(val)) { arr.push(val); save(); }
}
function streakNow() {
  let n = 0; const d = new Date(); if (!S.log[dkey(d)]) d.setDate(d.getDate() - 1);
  while (S.log[dkey(d)]) { n++; d.setDate(d.getDate() - 1); } return n;
}
let logM = (() => { const d = new Date(); return { y: d.getFullYear(), m: d.getMonth() }; })();
function renderLog() {
  const box = $('#logBox'); const { y, m } = logM; const first = new Date(y, m, 1).getDay(), days = new Date(y, m + 1, 0).getDate(); const tk = todayKey();
  const cnt = { pray: 0, worship: 0, hymn: 0, read: 0 };
  let cells = ['일', '월', '화', '수', '목', '금', '토'].map(w => `<div class="wd">${w}</div>`).join('');
  for (let i = 0; i < first; i++) cells += '<button class="dy om" tabindex="-1"></button>';
  for (let d = 1; d <= days; d++) {
    const k = `${y}-${pad2(m + 1)}-${pad2(d)}`; const f = dayFlags(S.log[k] || {}); LOGF.forEach(([id]) => { if (f[id]) cnt[id]++; });
    const all = f.pray && f.worship && f.hymn && f.read;
    cells += `<button class="dy${k === tk ? ' today' : ''}${all ? ' full' : ''}" data-k="${k}"><span>${d}</span><span class="dots4">${LOGF.map(([id, , , c]) => f[id] ? `<i class="${c}"></i>` : '').join('')}</span></button>`;
  }
  const st = streakNow();
  box.innerHTML = `<h2 style="font-family:var(--serif);font-size:24px;margin:4px 0 12px">출석 체크</h2>
  <p class="streak">${st ? `🔥 ${st}일 연속 기록 중이에요` : '오늘 첫 기록을 남겨 보세요'}</p>
  <div class="stat4">${LOGF.map(([id, n, ic]) => `<div><b>${cnt[id]}</b>${ic} ${n}</div>`).join('')}</div>
  <div class="mnav"><button class="ico" id="mPrev" aria-label="이전 달"><svg viewBox="0 0 24 24"><path d="m15 5-7 7 7 7"/></svg></button><b>${y}년 ${m + 1}월</b><button class="ico" id="mNext" aria-label="다음 달"><svg viewBox="0 0 24 24"><path d="m9 5 7 7-7 7"/></svg></button></div>
  <div class="cal">${cells}</div>
  <div class="lg">${LOGF.map(([, n, , c]) => `<span><i class="${c}"></i>${n}</span>`).join('')}<span>네 가지 모두 하면 파란 칸</span></div>`;
  $('#mPrev').onclick = () => { logM.m--; if (logM.m < 0) { logM.m = 11; logM.y--; } renderLog(); };
  $('#mNext').onclick = () => { logM.m++; if (logM.m > 11) { logM.m = 0; logM.y++; } renderLog(); };
  $$('.dy[data-k]', box).forEach(b => b.onclick = () => openDay(b.dataset.k));
}
function openDay(k) {
  const [y, mo, d] = k.split('-').map(Number); const dt = new Date(y, mo - 1, d);
  $('#dayTitle').textContent = dt.toLocaleDateString('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' });
  const e = S.log[k] || {}; const hy = e.hymns || [];
  const opts = allHymns().map(h => `<option value="${esc(h.title)}">${esc(h.title)}${h.ko ? ' · ' + esc(h.ko) : ''}</option>`).join('');
  $('#dayBody').innerHTML = `
  <div class="chk4" style="margin-bottom:6px"><button data-f="pray" class="${e.pray ? 'on' : ''}"><span>🙏</span>기도함</button><button data-f="worship" class="${e.worship ? 'on' : ''}"><span>⛪</span>예배함</button></div>
  <div class="dsec"><h4>🎵 찬송함</h4><div>${hy.map((t, i) => `<span class="chip2">${esc(t)}<button data-rh="${i}" aria-label="삭제">✕</button></span>`).join('') || '<span class="note" style="margin:0">찬송을 재생하면 자동으로 기록돼요</span>'}</div>
    <div style="display:flex;gap:8px;margin-top:8px"><select id="hySel" style="flex:1;min-width:0;width:0;padding:10px;border:1px solid var(--line);border-radius:10px;background:var(--paper);color:var(--ink);font-size:14px">${opts}</select><button class="mini pri" id="hyAdd">추가</button></div></div>
  <div class="dsec"><h4>📖 읽음</h4><input id="rdTxt" type="text" maxlength="60" value="${esc(e.read || '')}" placeholder="예) 마태복음 3:6 ~ 5:6" style="width:100%;padding:12px;border:1px solid var(--line);border-radius:10px;background:var(--paper);color:var(--ink);font-size:16px">
    ${e.chs && e.chs.length ? `<p class="note" style="margin:8px 0 0">앱에서 연 장: ${e.chs.map(esc).join(', ')}</p>` : ''}</div>`;
  const refresh = () => { logTidy(k); save(); openDay(k); if ($('#v-log').classList.contains('on')) renderLog(); if ($('#v-home').classList.contains('on')) renderHomeChecks(); };
  $$('#dayBody .chk4 button').forEach(b => b.onclick = () => { const en = logEntry(k); en[b.dataset.f] = en[b.dataset.f] ? 0 : 1; vib(15); refresh(); });
  $$('[data-rh]').forEach(b => b.onclick = () => { logEntry(k).hymns.splice(+b.dataset.rh, 1); refresh(); });
  $('#hyAdd').onclick = () => { const t = $('#hySel').value; const en = logEntry(k); en.hymns = en.hymns || []; if (!en.hymns.includes(t)) en.hymns.push(t); refresh(); };
  $('#rdTxt').onchange = e2 => { logEntry(k).read = e2.target.value.trim(); logTidy(k); save(); if ($('#v-log').classList.contains('on')) renderLog(); if ($('#v-home').classList.contains('on')) renderHomeChecks(); };
  showSheet('sh-day');
}
function renderHomeChecks() {
  const box = $('#hChecks'); if (!box) return; const k = todayKey(); const f = dayFlags(S.log[k] || {});
  box.innerHTML = LOGF.map(([id, n, ic]) => `<button data-f="${id}" class="${f[id] ? 'on' : ''}"><span>${ic}</span>${n}</button>`).join('');
  $$('button', box).forEach(b => b.onclick = () => {
    const id = b.dataset.f;
    if (id === 'pray' || id === 'worship') { const en = logEntry(k); en[id] = en[id] ? 0 : 1; logTidy(k); save(); vib(15); renderHomeChecks(); toast(en[id] ? (id === 'pray' ? '기도 체크 🙏' : '예배 체크 ⛪') : '체크를 풀었어요'); }
    else openDay(k);
  });
  const s = $('#hStreak'); if (s) { const st = streakNow(); s.textContent = st ? `🔥 ${st}일 연속` : ''; }
}
let chT = 0;
function trackChapter() {
  clearTimeout(chT);
  chT = setTimeout(() => { if ($('#v-bible').classList.contains('on') && !document.hidden) logAddAuto('ch', `${BOOKS[S.b][0]} ${S.c}${S.b === 18 ? '편' : '장'}`); }, 20000);
}

/* ============ 홈 ============ */
const CONFIG = window.APP_CONFIG || {};
const API = (CONFIG.prayerApi || '').replace(/\/+$/, '');
function cleanName(s) { return String(s || '').trim().replace(/\s+/g, ' ').replace(/님$/, '').slice(0, 12); }
/* 오늘의 말씀: [책, 장, 시작절, 끝절] — 책 번호는 BOOKS 순서(0부터) */
const VOD = [[39,22,39,39],[43,16,31,31],[18,25,5,5],[8,17,47,47],[18,51,10,10],[18,23,2,2],[18,73,26,26],[23,33,3,3],[39,5,16,16],[44,5,3,3],[44,12,1,1],[50,3,16,16],[65,22,20,20],[20,3,11,11],[19,27,17,17],[49,2,3,3],[23,1,5,5],[44,3,23,23],[46,4,16,16],[19,3,5,5],[39,17,20,20],[2,19,18,18],[1,33,14,14],[42,20,29,29],[39,6,21,21],[45,13,13,13],[58,1,12,12],[46,4,18,18],[39,7,7,7],[8,2,2,2],[18,139,23,23],[34,3,17,17],[58,1,22,22],[54,1,7,7],[50,3,15,15],[44,8,31,31],[18,147,3,3],[18,121,1,1],[22,40,31,31],[19,12,25,25],[18,37,23,23],[18,16,8,8],[18,100,5,5],[65,1,8,8],[65,21,4,4],[23,17,7,7],[18,63,1,1],[46,5,17,17],[39,22,37,37],[39,5,3,3],[9,22,2,2],[41,19,10,10],[18,103,2,2],[45,15,58,58],[22,60,1,1],[13,7,14,14],[49,4,6,6],[29,5,24,24],[41,15,7,7],[18,150,6,6],[4,31,6,6],[18,27,4,4],[4,6,5,5],[49,2,5,5],[22,55,6,6],[61,4,16,16],[18,18,1,1],[18,62,5,5],[22,58,11,11],[18,127,1,1],[43,2,38,38],[42,1,12,12],[18,119,130,130],[41,12,7,7],[57,10,23,23],[19,14,26,26],[22,43,4,4],[18,34,18,18],[39,5,8,8],[49,3,14,14],[18,27,1,1],[22,26,3,3],[18,37,7,7],[18,40,1,1],[18,119,9,9],[49,4,4,4],[41,11,9,9],[44,8,1,1],[39,6,25,25],[19,31,25,25],[18,57,1,1],[20,3,1,1],[39,7,12,12],[43,4,12,12],[50,3,14,14],[26,12,3,3],[39,6,14,14],[44,6,23,23],[13,16,9,9],[48,2,10,10],[18,100,4,4],[42,3,17,17],[44,12,21,21],[42,14,15,15],[45,15,10,10],[65,22,13,13],[18,56,3,3],[40,9,23,23],[3,23,19,19],[35,3,17,17],[18,30,5,5],[41,2,11,11],[19,3,6,6],[18,46,10,10],[18,33,4,4],[42,13,34,34],[19,15,1,1],[59,5,7,7],[19,1,7,7],[44,5,1,1],[27,6,3,3],[18,42,5,5],[22,43,1,1],[23,29,12,12],[23,29,13,13],[18,90,12,12],[22,55,8,8],[18,92,1,1],[18,42,1,1],[18,115,1,1],[5,1,9,9],[58,4,7,7],[22,46,4,4],[18,18,2,2],[5,24,15,15],[18,32,8,8],[40,10,45,45],[18,136,1,1],[9,22,31,31],[18,103,8,8],[20,4,9,9],[20,12,1,1],[47,5,23,23],[51,5,16,16],[44,10,17,17],[18,34,4,4],[19,15,13,13],[23,32,17,17],[18,118,6,6],[18,28,7,7],[55,3,5,5],[46,9,7,7],[19,17,22,22],[41,6,36,36],[18,84,10,10],[4,31,8,8],[49,4,19,19],[42,1,4,4],[18,100,1,1],[18,31,24,24],[44,15,13,13],[47,5,22,22],[58,1,17,17],[12,29,11,11],[60,3,9,9],[18,19,1,1],[18,138,8,8],[61,3,18,18],[44,12,12,12],[57,13,5,5],[18,119,105,105],[18,5,3,3],[19,19,21,21],[49,1,6,6],[45,16,13,13],[59,2,9,9],[22,40,29,29],[3,6,24,24],[18,1,1,1],[32,6,8,8],[38,3,10,10],[1,20,12,12],[42,15,12,12],[18,146,5,5],[42,14,1,1],[22,41,10,10],[22,6,8,8],[48,4,2,2],[39,7,24,24],[44,12,2,2],[18,46,1,1],[19,16,24,24],[18,103,1,1],[45,2,9,9],[58,5,16,16],[19,11,25,25],[52,3,3,3],[17,23,10,10],[49,4,8,8],[19,3,9,9],[18,118,24,24],[18,121,3,3],[10,8,56,56],[26,3,17,17],[18,107,1,1],[18,37,3,3],[51,5,18,18],[18,40,2,2],[42,15,7,7],[18,126,5,5],[28,2,28,28],[1,14,14,14],[23,29,11,11],[18,55,22,22],[19,22,6,6],[18,50,15,15],[32,5,2,2],[3,6,26,26],[4,10,12,12],[39,5,6,6],[8,16,7,7],[0,12,2,2],[18,66,20,20],[44,8,28,28],[39,5,4,4],[42,15,9,9],[14,7,10,10],[25,36,26,26],[41,18,1,1],[18,94,19,19],[39,6,34,34],[18,37,4,4],[39,11,29,29],[42,10,11,11],[23,31,3,3],[42,1,1,1],[16,4,14,14],[20,4,12,12],[18,95,1,1],[4,33,27,27],[41,12,32,32],[18,122,1,1],[22,30,21,21],[42,14,6,6],[19,13,20,20],[45,1,18,18],[12,16,11,11],[48,2,8,8],[18,119,11,11],[18,23,1,1],[18,145,18,18],[12,16,34,34],[44,8,38,38],[48,6,11,11],[22,30,15,15],[47,6,9,9],[57,11,1,1],[0,2,18,18],[18,37,5,5],[54,3,16,16],[43,20,35,35],[5,1,8,8],[18,24,1,1],[18,121,2,2],[18,91,1,1],[17,19,25,25],[42,4,24,24],[0,1,1,1],[18,4,8,8],[1,15,2,2],[57,13,8,8],[18,34,8,8],[28,2,13,13],[18,86,5,5],[18,8,3,3],[22,54,10,10],[48,4,32,32],[18,139,1,1],[10,19,12,12],[44,5,8,8],[57,11,6,6],[18,62,1,1],[39,5,14,14],[46,12,9,9],[41,1,37,37],[39,4,4,4],[58,1,2,2],[43,1,8,8],[19,18,10,10],[19,4,23,23],[4,8,3,3],[50,3,23,23],[37,4,6,6],[39,24,35,35],[40,11,24,24],[39,6,24,24],[39,16,24,24],[18,133,1,1],[18,91,2,2],[22,43,2,2],[39,18,20,20],[50,1,17,17],[50,3,12,12],[18,36,5,5],[4,7,9,9],[0,28,15,15],[18,139,14,14],[19,10,12,12],[18,91,11,11],[36,2,9,9],[44,8,26,26],[46,5,7,7],[39,28,20,20],[61,3,1,1],[19,16,3,3],[24,3,25,25],[42,10,10,10],[57,4,12,12],[42,1,14,14],[53,4,12,12],[39,5,44,44],[44,10,9,9],[18,25,4,4],[18,116,1,1],[39,11,28,28],[50,3,2,2],[39,6,33,33],[34,3,19,19],[61,4,18,18],[64,1,24,24],[41,6,38,38],[6,6,12,12],[18,27,14,14],[61,5,4,4],[42,14,27,27],[49,4,7,7],[41,6,31,31],[61,4,7,7],[39,9,37,37],[42,11,25,25],[61,4,8,8],[18,127,3,3],[41,9,23,23],[57,4,16,16],[57,12,1,1],[61,4,19,19],[40,10,27,27],[34,2,4,4],[18,23,4,4],[39,28,19,19],[42,6,35,35],[42,15,13,13],[24,3,23,23],[18,1,3,3],[33,1,7,7],[39,6,19,19],[22,43,19,19],[22,53,5,5],[3,6,25,25],[19,16,9,9],[42,15,5,5],[49,4,13,13],[45,10,13,13],[18,34,1,1],[39,6,6,6],[58,1,5,5],[19,9,10,10],[41,24,6,6],[42,8,32,32],[18,1,2,2],[22,9,6,6],[51,5,17,17],[15,8,10,10],[44,13,10,10],[65,3,20,20],[22,55,11,11],[22,41,13,13],[22,40,8,8],[18,121,7,7],[24,3,22,22],[18,96,1,1],[19,17,17,17],[48,3,20,20],[59,5,6,6],[48,6,10,10],[0,50,20,20],[39,5,9,9],[18,8,4,4],[19,3,27,27],[18,19,14,14],[17,1,21,21],[44,8,18,18],[0,1,27,27],[18,119,50,50],[39,4,19,19],[42,16,33,33],[59,1,3,3],[57,12,2,2],[39,19,26,26],[58,4,8,8],[59,4,8,8],[53,6,6,6],[42,3,16,16],[42,14,16,16],[61,1,9,9],[32,7,7,7],[42,8,12,12],[44,8,37,37],[44,1,16,16],[18,103,12,12],[18,16,11,11],[45,13,4,4],[40,12,30,30],[40,1,15,15],[19,18,21,21],[18,23,6,6]];
function vodOn(d) { const n = Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5); return VOD[n % VOD.length]; }
function vodToday() { return vodOn(new Date()); }
let vodAlt = false;
async function vodText(r, tr) {
  const d = await loadTr(tr); const [b, c, v1, v2] = r; const ch = d[b] && d[b][c - 1]; if (!ch) return '';
  const out = []; for (let v = v1; v <= v2; v++) if (ch[v - 1]) out.push(ch[v - 1]); return out.join(' ');
}
function greet() { const h = new Date().getHours(); return h < 5 ? '평안한 밤이에요' : h < 11 ? '좋은 아침이에요' : h < 18 ? '평안한 오후예요' : '평안한 저녁이에요'; }
function ago(ts) {
  const s = Math.max(1, Math.round((Date.now() - ts) / 1000));
  if (s < 60) return '방금'; if (s < 3600) return Math.round(s / 60) + '분 전'; if (s < 86400) return Math.round(s / 3600) + '시간 전';
  if (s < 86400 * 30) return Math.round(s / 86400) + '일 전'; return new Date(ts).toLocaleDateString('ko-KR', { month: 'long', day: 'numeric' });
}
S.did = S.did || ('d' + Math.random().toString(36).slice(2, 10));
let prayFilter = 'all', others = [], othersState = 'idle';
const SAMPLE = [
  { id: 'x1', n: '성도', t: '오늘 하루도 주님 안에서 평안하게 해 주세요. 가족 모두 건강하게 지켜 주시기를 기도합니다.', ts: Date.now() - 36e5 * 3, sample: 1 },
  { id: 'x2', n: '성도', t: '시험을 앞둔 아이에게 담대함과 지혜를 주세요.', ts: Date.now() - 36e5 * 20, sample: 1 },
  { id: 'x3', n: '성도', t: '아픈 이웃들이 속히 회복되고, 외로운 분들이 위로받게 하소서.', ts: Date.now() - 36e5 * 52, sample: 1 }
];
async function fetchOthers() {
  if (!API) { others = SAMPLE; othersState = 'sample'; return; }
  othersState = 'loading';
  try {
    const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 8000);
    const r = await fetch(`${API}/prayers.json?orderBy="ts"&limitToLast=40`, { signal: ctl.signal }); clearTimeout(to);
    if (!r.ok) throw new Error(r.status);
    const j = (await r.json()) || {};
    others = Object.entries(j).map(([id, p]) => ({ id, n: p.n || '', t: p.t || '', ts: p.ts || 0 })).filter(p => p.t).sort((a, b) => b.ts - a.ts);
    othersState = 'ok';
  } catch (e) { othersState = 'err'; }
}
async function postPrayer(p) {
  if (!API) return true;
  try {
    const r = await fetch(`${API}/prayers.json`, { method: 'POST', body: JSON.stringify({ n: p.n, t: p.t, ts: p.ts, d: S.did }) });
    if (!r.ok) return false; const j = await r.json(); p.sid = j.name; return true;
  } catch (e) { return false; }
}
async function reportPrayer(id) { if (!API || String(id).startsWith('x')) return; try { await fetch(`${API}/reports/${encodeURIComponent(id)}/${S.did}.json`, { method: 'PUT', body: 'true' }); } catch (e) {} }
async function removePrayer(p) { if (API && p.sid) { try { await fetch(`${API}/prayers/${encodeURIComponent(p.sid)}.json`, { method: 'DELETE' }); } catch (e) {} } }

function prayerItem(p, mine) {
  const nm = mine ? (S.name ? S.name + '님' : '나') : (p.n ? esc(p.n) + '님' : '익명');
  return `<div class="pi" data-id="${esc(p.id)}"><div class="ph"><b>${mine ? esc(nm) : nm}</b>${p.sample ? '<span class="tag">예시</span>' : ''}${mine ? '<span class="tag">내 기도</span>' : ''}<span class="sp"></span><span>${ago(p.ts)}</span></div><p>${esc(p.t)}</p><div class="pa">${mine ? '<button data-a="del">지우기</button>' : '<button data-a="amen">🙏 함께 기도해요</button><button data-a="rep">신고</button>'}</div></div>`;
}
function renderPrayerList() {
  const box = $('#pList'); if (!box) return;
  const mine = S.prayers.slice().sort((a, b) => b.ts - a.ts);
  const hid = new Set(S.hidden);
  const oth = others.filter(p => !hid.has(p.id) && !(p.sid && 0));
  const mineIds = new Set(S.prayers.map(p => p.sid).filter(Boolean));
  const oth2 = oth.filter(p => !mineIds.has(p.id));
  let items;
  if (prayFilter === 'mine') items = mine.map(p => ({ ...p, _m: 1 }));
  else items = [...mine.map(p => ({ ...p, _m: 1 })), ...oth2].sort((a, b) => b.ts - a.ts);
  let h = items.length ? items.map(p => prayerItem(p, !!p._m)).join('') : `<div class="empty" style="padding:22px 0">${prayFilter === 'mine' ? '아직 남긴 기도가 없어요.' : '아직 기도가 없어요. 첫 기도를 남겨 보세요.'}</div>`;
  if (prayFilter !== 'mine') {
    if (othersState === 'loading') h += '<p class="pnote">다른 분들의 기도를 불러오는 중…</p>';
    if (othersState === 'err') h += '<p class="pnote">다른 분들의 기도를 불러오지 못했어요. 네트워크를 확인해 주세요. <button class="mini" id="pRetry">다시 불러오기</button></p>';
    if (othersState === 'sample') h += '<p class="pnote">지금은 이 기기에만 저장돼요. 교회 공유 서버에 연결하면 다른 분들의 기도가 이곳에 나타나요. (위의 “예시”는 모양을 보여 드리려는 문구예요.)</p>';
  }
  box.innerHTML = h;
  $$('.pi', box).forEach(el => {
    const id = el.dataset.id;
    $$('[data-a]', el).forEach(b => b.onclick = () => {
      const a = b.dataset.a;
      if (a === 'amen') { b.classList.toggle('on'); b.textContent = b.classList.contains('on') ? '🙏 함께 기도했어요' : '🙏 함께 기도해요'; vib(20); }
      if (a === 'rep') { S.hidden.push(id); save(); reportPrayer(id); renderPrayerList(); toast('신고했고, 이 글은 숨겼어요'); }
      if (a === 'del') {
        const i = S.prayers.findIndex(p => p.id === id); if (i < 0) return;
        const p = S.prayers[i]; S.prayers.splice(i, 1); save(); removePrayer(p); renderPrayerList();
        toast('기도를 지웠어요', () => { S.prayers.push(p); save(); postPrayer(p).then(() => save()); renderPrayerList(); });
      }
    });
  });
  const rt = $('#pRetry'); if (rt) rt.onclick = async () => { await fetchOthers(); renderPrayerList(); };
}
async function renderVod() {
  const box = $('#vodBox'); if (!box) return;
  const r = vodToday();
  const tr = vodAlt ? (S.tr === 'krv' ? 'kjv' : 'krv') : S.tr;
  let t = ''; try { t = await vodText(r, tr); } catch (e) { t = ''; }
  const ref = `${BOOKS[r[0]][0]} ${r[1]}:${r[2]}${r[3] > r[2] ? '-' + r[3] : ''}`;
  box.innerHTML = t ? `<q>${esc(t)}</q><cite>${esc(ref)} · ${esc(TR[tr].name)}</cite>
    <div class="acts"><button class="pri" id="vGo">이 장 읽기</button><button id="vAlt">${tr === 'krv' ? 'English' : '한글'}</button><button id="vCp">복사</button></div>` : '<div class="empty">말씀을 불러오지 못했어요.</div>';
  const g = $('#vGo'); if (g) g.onclick = () => { setTab('bible'); go(r[0], r[1], r[2]); };
  const al = $('#vAlt'); if (al) al.onclick = () => { vodAlt = !vodAlt; renderVod(); };
  const cp = $('#vCp'); if (cp) cp.onclick = () => copyText(`${t}\n— ${ref} (${TR[tr].name})`);
}
function renderHome() {
  const box = $('#homeBox'); const d = new Date();
  const nm = S.name ? `<em>${esc(S.name)}</em>님,` : '';
  const last = `${BOOKS[S.b][0]} ${S.c}${S.b === 18 ? '편' : '장'}`;
  box.innerHTML = `
  <div class="hh0"><div class="gr"><h1>${nm}<br>${greet()}</h1><small>${d.toLocaleDateString('ko-KR', { month: 'long', day: 'numeric', weekday: 'long' })}</small></div>
    <button class="ico" id="hmTh" aria-label="어둡게/밝게">${(document.documentElement.dataset.theme === 'dark' || document.documentElement.dataset.theme === 'black') ? '☀️' : '🌙'}</button><button class="ico" id="hmSet" aria-label="설정"><svg viewBox="0 0 24 24"><path d="M4 7h10M18 7h2M4 17h2M10 17h10"/><circle cx="16" cy="7" r="2"/><circle cx="8" cy="17" r="2"/></svg></button></div>
  <div class="card vod"><div class="cl"><span>오늘의 말씀</span></div><div id="vodBox"><div class="skeleton" style="padding:14px"><div class="bar"></div><div class="bar"></div></div></div></div>
  <div class="card"><div class="cl"><span>오늘의 체크</span><span id="hStreak" style="flex:none"></span></div><div class="chk4" id="hChecks"></div></div>
  <div class="quick">
    <button id="qBible"><svg viewBox="0 0 24 24"><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v16H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5V5.5"/></svg>이어 읽기<small>${esc(last)}</small></button>
    <button id="qHymn"><svg viewBox="0 0 24 24"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg>찬송<small>${allHymns().length}곡</small></button>
    <button id="qMarks"><svg viewBox="0 0 24 24"><path d="m4 20 1-4 10.5-10.5 3 3L8 19zM14 7l3 3M3 21h18"/></svg>형광펜<small>${Object.keys(S.hl).length}문장</small></button>
  </div>
  <div class="card"><div class="cl"><span>기도 남기기</span></div>
    <div class="pform"><textarea id="pTxt" maxlength="300" placeholder="오늘 드리고 싶은 기도를 적어 보세요"></textarea>
    <div class="pr"><label><input type="checkbox" id="pAnon"> 이름 없이 올리기</label><span class="cnt" id="pCnt">0/300</span><button class="mini pri" id="pSend">올리기</button></div></div></div>
  <div class="card"><div class="cl"><span>함께 드리는 기도</span></div>
    <div class="pfil"><button data-f="all" class="${prayFilter === 'all' ? 'on' : ''}">모두</button><button data-f="mine" class="${prayFilter === 'mine' ? 'on' : ''}">내 기도</button></div>
    <div id="pList"></div></div>
  <button class="tourbtn" id="hmTour"><span>📖</span> 사용법 다시 보기<small>이미지로 보는 6장 안내</small></button>`;
  $('#hmTour').onclick = openTour;
  $('#hmSet').onclick = openSettings;
  $('#hmTh').onclick = () => { const cur = document.documentElement.dataset.theme; S.theme = (cur === 'dark' || cur === 'black') ? 'paper' : 'dark'; save(); applyLook(); renderHome(); };
  $('#qBible').onclick = () => setTab('bible'); $('#qHymn').onclick = () => setTab('hymn'); $('#qMarks').onclick = () => setTab('marks');
  const ta = $('#pTxt'); ta.oninput = () => { $('#pCnt').textContent = ta.value.length + '/300'; };
  $('#pSend').onclick = async () => {
    const t = ta.value.replace(/\n{3,}/g, '\n\n').trim();
    if (t.length < 2) { toast('기도를 한 줄 이상 적어 주세요'); return; }
    if (Date.now() - S.lastPray < 20000) { toast('잠시 뒤에 다시 올려 주세요'); return; }
    const p = { id: 'm' + Date.now().toString(36), n: $('#pAnon').checked ? '' : (S.name || ''), t, ts: Date.now() };
    const btn = $('#pSend'); btn.disabled = true;
    const ok = await postPrayer(p);
    btn.disabled = false;
    S.prayers.push(p); S.lastPray = Date.now(); { const en = logEntry(todayKey()); en.pray = 1; } save(); renderHomeChecks(); ta.value = ''; $('#pCnt').textContent = '0/300';
    prayFilter = 'all'; $$('.pfil button').forEach(b => b.classList.toggle('on', b.dataset.f === 'all')); renderPrayerList(); vib(30);
    toast(!API ? '기도를 남겼어요 (이 기기에 저장)' : ok ? '기도를 올렸어요 🙏' : '인터넷이 불안정해 이 기기에만 저장했어요');
  };
  $$('.pfil button').forEach(b => b.onclick = () => { prayFilter = b.dataset.f; $$('.pfil button').forEach(x => x.classList.toggle('on', x === b)); renderPrayerList(); });
  renderVod(); renderPrayerList(); renderHomeChecks();
  fetchOthers().then(renderPrayerList);
}

/* ============ 사용법(이미지 튜토리얼) ============ */
const TOUR = [
  ['홈에서 시작해요', '매일 새로운 오늘의 말씀과 기도 나눔이 있어요. 설정은 오른쪽 위 버튼이에요.'],
  ['형광펜 칠하기', '성경에서 문장을 두 번 톡톡 치면 펜이 나타나요. 쓱 그으면 한 문장이 칠해져요.'],
  ['소리 내어 읽어 드려요', '아래 ▶를 누르면 문장마다 읽어 줘요. 위에서 책·장과 번역(영어 포함)을 바꿔요.'],
  ['찬송 악보와 함께', '재생하면 지금 부르는 음과 가사가 빨갛게 따라가요. 템포·키·악기도 바꿀 수 있어요.'],
  ['출석 달력', '기도·예배·찬송·읽음을 날짜별로 남겨요. 날짜를 누르면 적은 찬송과 읽은 구절도 볼 수 있어요.'],
  ['설정에서 내 방식대로', '다크 모드, 글자 크기, 낭독 목소리, 매일 말씀·기도 시간 알림을 여기서 바꿔요.']
];
let tourI = 0;
function showTour(i) {
  tourI = i; const last = i === TOUR.length - 1;
  $('#tImg').src = `img/tut${i + 1}.png`; $('#tH').textContent = TOUR[i][0]; $('#tP').textContent = TOUR[i][1];
  $('#tDots').innerHTML = TOUR.map((_, k) => `<i class="${k === i ? 'on' : ''}"></i>`).join('');
  $('#tNext').textContent = last ? '시작하기' : '다음'; $('#tSkip').style.visibility = last ? 'hidden' : '';
}
function openTour() { showTour(0); $('#tour').classList.add('on'); }
function closeTour() { $('#tour').classList.remove('on'); S.tour = 1; save(); }
function askTour() { const a = $('#tAsk'); a.classList.add('on'); $('#taYes').onclick = () => { a.classList.remove('on'); openTour(); }; $('#taNo').onclick = () => { a.classList.remove('on'); S.tour = 1; save(); toast('홈 맨 아래에서 언제든 다시 볼 수 있어요'); }; }
$('#tNext').onclick = () => { if (tourI >= TOUR.length - 1) closeTour(); else showTour(tourI + 1); };
$('#tSkip').onclick = closeTour;
(() => { let x0 = null; const st = $('#tour'); st.addEventListener('touchstart', e => { x0 = e.touches[0].clientX; }, { passive: true });
  st.addEventListener('touchend', e => { if (x0 === null) return; const dx = e.changedTouches[0].clientX - x0; x0 = null;
    if (dx < -50 && tourI < TOUR.length - 1) showTour(tourI + 1); else if (dx > 50 && tourI > 0) showTour(tourI - 1); }, { passive: true }); })();
/* 처음 실행: 이름 묻기 */
function askName() {
  const w = $('#welcome'); w.classList.add('on'); const inp = $('#wName');
  const done = (skip) => { S.name = skip ? '' : cleanName(inp.value); save(); w.classList.remove('on'); renderHome(); if (!S.tour) askTour(); else if (S.name) toast(S.name + '님, 환영해요'); };
  $('#wGo').onclick = () => done(!inp.value.trim()); $('#wSkip').onclick = () => done(true);
  inp.onkeydown = e => { if (e.key === 'Enter') { e.preventDefault(); $('#wGo').click(); } };
  setTimeout(() => inp.focus(), 250);
}

/* ============ 시작 ============ */
applyLook();
setPlayUI();
const startTab = (location.hash || '').replace('#', '');
showChapter({ verse: 0, keepScroll: true }).then(() => { if (['bible', 'hymn', 'marks', 'log'].includes(startTab)) setTab(startTab); });
if (!['bible', 'hymn', 'marks', 'log'].includes(startTab)) setTab('home');
if (S.name === null) askName(); else if (!S.tour) askTour();
setTimeout(() => { if (S.notif || S.pnotif) scheduleVerseAlerts(); }, 2500);
window.__app = { S, go, setTab, TTS, HY, arm, pen, renderHome };
