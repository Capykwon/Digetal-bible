/* 추가 찬송 — 가사·곡 모두 저작권 만료(Public Domain) */
window.HYMNS.push(
{
  id: 'hark-herald',
  title: 'Hark! The Herald Angels Sing',
  ko: '천사 찬송하기를 (성탄)',
  meta: '가사 Charles Wesley, 1739 · 곡 Felix Mendelssohn, 1840',
  abc: `X:3
T:Hark! The Herald Angels Sing
M:4/4
L:1/4
Q:1/4=104
K:G
D G G>F | G B B A |
w:1.~Hark! the her- ald an- gels sing _
w:2.~Christ, by high- est heav'n a- dored _
w:3.~Hail the heav'n- born Prince of Peace _
d d d>c | B A B2 |
w:Glo- ry to the new- born King;
w:Christ, the ev- er- last- ing Lord;
w:Hail the Son of Right- eous- ness!
D G G>F | G B B A |
w:Peace on earth and mer- cy mild _
w:Late in time be- hold Him come _
w:Light and life to all He brings _
d A A F | F E D2 |
w:God and sin- ners rec- on- ciled.
w:Off- spring of a Vir- gin's womb.
w:Ris'n with heal- ing in His wings.
d d d G | c B B A |
w:Joy- ful, all ye na- tions, rise _
w:Veiled in flesh the God- head see _
w:Mild He lays His glo- ry by _
e e e d | c B c2 |
w:Join the tri- umph of the skies;
w:Hail th'in- car- nate De- i- ty,
w:Born that man no more may die,
A B/c/ d>G | G A B2 |
w:With th' an- gel- ic host pro- claim,
w:Pleased as man with men to dwell _
w:Born to raise the sons of earth _
e>e e d | c B c2 |
w:"Christ is born in Beth- le- hem!"
w:Je- sus, our Em- man- u- el.
w:Born to give them sec- ond birth.
D G G>F | G B B A |
w:Hark! the her- ald an- gels sing _
w:Hark! the her- ald an- gels sing _
w:Hark! the her- ald an- gels sing _
d d d>c | B A G2 |]
w:Glo- ry to the new- born King!
w:Glo- ry to the new- born King!
w:Glo- ry to the new- born King!
`
},
{
  id: 'adeste-fideles',
  title: 'O Come, All Ye Faithful',
  ko: '참 반가운 성도여 (성탄)',
  meta: '라틴어 원작 18세기 (John F. Wade) · 영역 Frederick Oakeley, 1841',
  abc: `X:4
T:O Come, All Ye Faithful
M:4/4
L:1/4
Q:1/4=96
K:G
G | G2 D G | A2 D2 | B A B c | B2 A G |
w:O come, all ye faith- ful, joy- ful and tri- umph- ant, _
G2 F E | F G A B | F2 E>D | D3 z |
w:O come ye, O come ye to Beth- le- hem; _
d2 c B | c2 B2 | A B G A | F>E D G |
w:Come and be- hold Him, born the King of an- gels; _ _
G F G A | G2 D B |
w:O come, let us a- dore Him,
B A B c | B2 A B |
w:O come, let us a- dore Him,
c B A G | F2 G c | B2 A>G | G3 z |]
w:O come, let us a- dore Him, Christ the Lord. _
`
},
{
  id: 'good-king-wenceslas',
  title: 'Good King Wenceslas',
  ko: '선한 왕 웬체슬라스',
  meta: '가사 John Mason Neale, 1853 · 곡 Piae Cantiones, 1582',
  abc: `X:5
T:Good King Wenceslas
M:4/4
L:1/4
Q:1/4=100
K:G
G G G A | G G D2 |
w:1.~Good King Wen- ces- las looked out,
w:2.~Hith- er, page, and stand by me,
w:3.~Bring me flesh and bring me wine,
w:4.~Page and mon- arch, forth they went,
w:5.~In his mas- ter's steps he trod,
E D E F | G2 G2 |
w:On the feast of Ste- phen,
w:If thou know'st it, tell- ing,
w:Bring me pine logs hith- er;
w:Forth they went to- geth- er;
w:Where the snow lay dint- ed;
G G G A | G G D2 |
w:When the snow lay round a- bout,
w:Yon- der peas- ant, who is he?
w:Thou and I will see him dine,
w:Through the rude wind's wild la- ment
w:Heat was in the ve- ry sod
E D E F | G2 G2 |
w:Deep and crisp and e- ven;
w:Where and what his dwell- ing?
w:When we bear them thith- er.
w:And the bit- ter weath- er.
w:Which the saint had print- ed.
d c B A | B A G2 |
w:Bright- ly shone the moon that night,
w:"Sire, he lives a good league hence,
w:Bring me flesh and bring me wine,
w:Sire, the night is dark- er now,
w:There- fore, Chris- tian men, be sure,
E D E F | G2 G2 |
w:Though the frost was cru- el,
w:Un- der- neath the moun- tain;
w:Bring me pine logs hith- er;
w:And the wind blows strong- er;
w:Wealth or rank pos- sess- ing,
D D E F | G G A2 |
w:When a poor man came in sight,
w:Right a- gainst the for- est fence,
w:Thou and I will see him dine,
w:Fails my heart, I know not how,
w:Ye who now will bless the poor,
d c B A | G2 c2 G4 |]
w:Gath'- ring win- ter fu- el. _
w:By Saint Ag- nes' foun- tain." _
w:When we bear them thith- er. _
w:I can go no long- er." _
w:Shall your- selves find bless- ing. _
`
},
{
  id: 'sweet-by-and-by',
  title: 'In the Sweet By and By',
  ko: '달콤한 훗날 (영어 찬송)',
  meta: '가사 Sanford F. Bennett, 1868 · 곡 Joseph P. Webster, 1868',
  abc: `X:6
T:In the Sweet By and By
M:4/4
L:1/8
Q:1/4=88
K:F
F>G | A2 GF G2 FD | C4 z4 |
w:1.~There's a land that is fair- er than day,
w:2.~We shall sing on that beau- ti- ful shore
w:3.~To our boun- ti- ful Fa- ther a- bove,
F>G | A2 A>A c2 c>A | G6 z2 |
w:And by faith we can see it a- far;
w:The me- lo- dious songs of the blessed;
w:We will of- fer our trib- ute of praise
F>G | A2 GF G2 FD | C4 z4 |
w:For the Fa- ther waits o- ver the way
w:And our spir- its shall sor- row no more,
w:For the glo- rious gift of His love
F>G | A2 GF G2 FE | F6 z2 |
w:To pre- pare us a dwell- ing place there.
w:Not a sigh for the bless- ing of rest.
w:And the bless- ings that hal- low our days.
A>B | c6 c>A | G6 G>A | B2 BB B2 AG | A6 z2 |
w:Ch.~In the sweet by and by, we shall meet on that beau- ti- ful shore;
A>B | c6 A>G | F6 FD | C2 FA G2 FE | F6 z2 |]
w:In the sweet by and by, we shall meet on that beau- ti- ful shore.
`
},
{
  id: 'jesus-bids-us-shine',
  title: 'Jesus Bids Us Shine',
  ko: '예수님이 빛나라 하시네',
  meta: '가사 Susan B. Warner, 1868 · 곡 W. E. M. Hackleman, 1915경',
  abc: `X:7
T:Jesus Bids Us Shine
M:4/4
L:1/8
Q:1/4=92
K:G
BD DG B2 Bc | B2 A2 A4 |
w:1.~Je- sus bids us shine with a clear, pure light,
w:2.~Je- sus bids us shine, first of all for Him;
w:3.~Je- sus bids us shine, then, for all a- round;
AD DF A2 B2 | AA GF G4 |
w:Like a lit- tle can- dle burn- ing in the night;
w:Well He sees and knows it, if our light is dim;
w:Man- y kinds of dark- ness in this world a- bound,
BD DG B2 d2 | d2 c2 c4 |
w:In this world of dark- ness we must shine,
w:He looks down from heav'n to see us shine,
w:Sin, and want, and sor- row; we must shine,
BD GA B d2 c | B2 A2 G4 |]
w:You in your small cor- ner, and I in mine.
w:You in your small cor- ner, and I in mine.
w:You in your small cor- ner, and I in mine.
`
}
);
