/* 저작권이 만료된(Public Domain) 찬송 — 가사: 퍼블릭 도메인 원문, 곡: 전래/고전 곡조 */
window.HYMNS = [
{
  id: 'amazing-grace',
  title: 'Amazing Grace',
  ko: '놀라운 은혜',
  meta: '가사 John Newton, 1779 · 곡 New Britain (Virginia Harmony, 1831)',
  abc: `X:1
T:Amazing Grace
M:3/4
L:1/8
Q:1/4=76
K:G
D2 | G4 (3BAG | B4 A2 | G4 E2 | D4 D2 |
w:1.~A- ma- zing _ _ grace how sweet the sound that
w:2.~'Twas grace that _ _ taught my heart to fear and
w:3.~Thro' ma- ny _ _ dan- gers, toils, and snares, I
w:4.~The Lord has _ _ prom- ised good to me, His
w:5.~When we've been _ _ there ten thou- sand years, bright
G4 (3BAG | B4 A B | d6- | d4 B2 |
w:saved a _ _ wretch like _ me I
w:grace my _ _ fears re- _ lieved; How
w:have al- _ _ read- y _ come; 'Tis
w:word my _ _ hope se- _ cures; He
w:shin- ing _ _ as the _ sun, we've
d4 (3BAG | B4 A2 | G4 E2 | D4 D2 |
w:once was _ _ lost, but now am found, was
w:pre- cious _ _ did that grace ap- pear, The
w:grace hath _ _ brought me safe thus far, and
w:will my _ _ shield and por- tion be, as
w:no less _ _ days to sing God's praise than
G4 (3BAG | B4 A2 | G6- | G4 |]
w:blind, but _ _ now I see.
w:hour I _ _ first be- lieved.
w:grace will _ _ lead me home.
w:long as _ _ life en- dures.
w:when we _ _ first be- gun.
`
},
{
  id: 'silent-night',
  title: 'Silent Night',
  ko: '고요한 밤 (성탄)',
  meta: '가사 Joseph Mohr, 1818 (영역 John F. Young, 1863) · 곡 Franz Gruber, 1818',
  abc: `X:2
T:Silent Night
M:3/4
L:1/4
Q:1/4=66
K:D
A>B A | F3 | A>B A | F3 |
w:1.~Si- lent night _ ho- ly night _
w:2.~Si- lent night _ ho- ly night _
w:3.~Si- lent night _ ho- ly night _
e2 e | c3 | d2 d | A3 |
w:All is calm all is bright
w:Shep- herds quake at the sight
w:Son of God love's pure light
B2 B | d>c B | A>B A | F3 |
w:Round yon Vir- gin Moth- er and child _
w:Glo- ries stream from heav- en a- far _
w:Ra- diant beams from thy ho- ly face _
B2 B | d>c B | A>B A | F3 |
w:Ho- ly in- fant so ten- der and mild
w:Heav'n- ly hosts sing Al- le- lu- ia _
w:With the dawn of re- deem- ing grace _
e2 e | g>e c | d3 | f3 |
w:Sleep in heav- en- ly peace _
w:Christ the Sav- ior is born _
w:Je- sus, Lord, at thy birth _
d A F | A>G E | D3- | D3 |]
w:Sleep in heav- en- ly peace _
w:Christ the Sav- ior is born _
w:Je- sus, Lord, at thy birth _
`
}
];

/* 사용자가 직접 넣는 곡의 입력 예시 */
window.ABC_TEMPLATE = `X:1
T:곡 제목
C:작사·작곡
M:4/4
L:1/4
Q:1/4=80
K:C
C D E F | G2 G2 |
w:1.~가- 사- 를 여- 기 에
w:2.~두- 번- 째 절 도 이 렇 게
`;
