/* 앱 설정 — APK로 배포할 때 이 파일만 고치면 됩니다.
   prayerApi: 교인들끼리 기도를 공유할 서버 주소(Firebase Realtime Database REST 주소).
   예) 'https://내프로젝트-default-rtdb.firebaseio.com'
   비워두면 기도는 이 기기에만 저장되고, 다른 사람의 기도는 '예시'만 보여요. */
window.APP_CONFIG = { prayerApi: 'https://digital-bible-913d3-default-rtdb.asia-southeast1.firebasedatabase.app', appName: '말씀과 찬송' };
