/* 흑인 영가 — 작자 미상의 전래곡(Public Domain), 가사 모두 전승 가사 */
window.HYMNS.push(
{
  id: 'michael-row',
  title: 'Michael, Row the Boat Ashore',
  ko: '마이클, 노를 저어라 (영가)',
  meta: '미국 흑인 영가 · 작자 미상 (Public Domain)',
  abc: `X:6
T:Michael, Row the Boat Ashore
M:4/4
L:1/4
Q:1/4=96
K:G
GB | d>B d e | d B d | e | d z B d |
w:1.~Mi- chael row the boat a- shore, Hal- le- lu- jah Mi- chael
w:2.~Sis- ter help to trim the sail, Hal- le- lu- jah Sis- ter
w:3.~Bro- ther lend a help- ing hand, Hal- le- lu- jah Bro- ther
d>B c B | A G A | (B A) | G z |]
w:1.~row the boat a- shore, Hal- le- lu- _ jah.
w:2.~help to trim the sail, Hal- le- lu- _ jah.
w:3.~lend a help- ing hand, Hal- le- lu- _ jah.
`
},
{
  id: 'old-time-religion',
  title: 'Give Me That Old Time Religion',
  ko: '옛 시절 믿음 (영가)',
  meta: '미국 흑인 영가 · 작자 미상 (Public Domain)',
  abc: `X:7
T:Give Me That Old Time Religion
M:4/4
L:1/4
Q:1/4=132
K:G
D/D/E | G2 G>G | E D G/G/G |
w:1.~Give me that old time re- li- gion Give me that
w:2.~It was good for Paul and Si- las It was good
w:3.~It will do when I am dy- ing It will do
A2 A>B | A G G/G/A | B2 B>B |
w:1.~old time re- li- gion Give me that old time re-
w:2.~for Paul and Si- las It was good for Paul and Si-
w:3.~when I am dy- ing It will do when I am dy-
A G2 E | D G A F | G2 |]
w:1.~li- gion It's good e- nough for me.
w:2.~las It's good e- nough for me.
w:3.~ing It's good e- nough for me.
`
},
{
  id: 'kum-ba-yah',
  title: 'Kum Ba Yah',
  ko: '쿰바야 (영가)',
  meta: '미국 영가 · 작자 미상 (Public Domain)',
  abc: `X:8
T:Kum Ba Yah
M:3/4
L:1/8
Q:1/4=60
K:C
CE | G>G G2 A A | G4 C E | G>G G2 F E | D4 C E |
w:1.~Kum ba yah my Lord kum ba yah Kum ba yah my Lord kum ba yah Kum ba
w:2.~Some- one's cry- ing Lord kum ba yah Some- one's cry- ing Lord kum ba yah Some- one's
w:3.~Some- one's pray- ing Lord kum ba yah Some- one's pray- ing Lord kum ba yah Some- one's
G>G G2 A A | G4 F2 | (E C) D D C2- | C4 |]
w:1.~yah my Lord kum ba yah Oh Lord _ kum ba yah _
w:2.~cry- ing Lord kum ba yah Oh Lord _ kum ba yah _
w:3.~pray- ing Lord kum ba yah Oh Lord _ kum ba yah _
`
}
);
